To see `preact-hot-loader` in action, edit `js/HelloWorld.jsx`
