
To see the live-updating and CSS injecting, simply perform changes to `app/static/_custom.css`