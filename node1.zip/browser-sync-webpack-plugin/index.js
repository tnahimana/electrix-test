const BrowserSyncPlugin = require('./lib/BrowserSyncPlugin')

module.exports = BrowserSyncPlugin
