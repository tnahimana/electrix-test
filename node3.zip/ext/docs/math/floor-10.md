# `Math.floor10` _(ext/math/floor-10)_

Decimal floor

```javascript
const floor10 = require("ext/math/floor-10");

floor10(55.59, -1); // 55.5
floor10(59, 1); // 50
```
