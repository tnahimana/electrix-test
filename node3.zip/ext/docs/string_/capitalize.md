# `string.capitalize()` _(ext/string\_/capitalize)_

Capitalize input string, e.g. convert `this is a test` into `This is a test`.

```javascript
const capitalize = require("ext/string_/capitalize");

capitalize.call("this is a test"); // This is a test
```
