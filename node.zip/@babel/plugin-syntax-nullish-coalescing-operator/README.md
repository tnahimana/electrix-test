# @babel/plugin-syntax-nullish-coalescing-operator

> Allow parsing of the nullish-coalescing operator

See our website [@babel/plugin-syntax-nullish-coalescing-operator](https://babeljs.io/docs/en/next/babel-plugin-syntax-nullish-coalescing-operator.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-nullish-coalescing-operator
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-nullish-coalescing-operator --dev
```
