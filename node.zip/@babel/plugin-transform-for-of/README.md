# @babel/plugin-transform-for-of

> Compile ES2015 for...of to ES5

See our website [@babel/plugin-transform-for-of](https://babeljs.io/docs/en/babel-plugin-transform-for-of) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-for-of
```

or using yarn:

```sh
yarn add @babel/plugin-transform-for-of --dev
```
