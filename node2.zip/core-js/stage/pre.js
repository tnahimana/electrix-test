var parent = require('./0');

require('../proposals/reflect-metadata');

module.exports = parent;
