module.exports = require('./full');
