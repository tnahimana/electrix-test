var parent = require('../actual/set-timeout');

module.exports = parent;
