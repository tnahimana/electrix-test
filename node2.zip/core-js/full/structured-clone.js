var parent = require('../actual/structured-clone');

module.exports = parent;
