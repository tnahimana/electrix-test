var parent = require('../actual/btoa');

module.exports = parent;
