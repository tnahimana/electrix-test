var parent = require('../actual/set-immediate');

module.exports = parent;
