var parent = require('../actual/unescape');

module.exports = parent;
