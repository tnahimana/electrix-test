var parent = require('../actual/parse-float');

module.exports = parent;
