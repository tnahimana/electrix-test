var parent = require('../actual/get-iterator');

module.exports = parent;
