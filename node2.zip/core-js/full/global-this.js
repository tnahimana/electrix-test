// TODO: remove from `core-js@4`
require('../modules/esnext.global-this');

var parent = require('../actual/global-this');

module.exports = parent;
