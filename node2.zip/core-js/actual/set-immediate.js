var parent = require('../stable/set-immediate');

module.exports = parent;
