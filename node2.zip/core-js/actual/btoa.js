var parent = require('../stable/btoa');

module.exports = parent;
