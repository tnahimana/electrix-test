var parent = require('../stable/parse-int');

module.exports = parent;
