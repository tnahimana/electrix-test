require('../modules/web.url-search-params');
require('../modules/web.url-search-params.size');
var path = require('../internals/path');

module.exports = path.URLSearchParams;
