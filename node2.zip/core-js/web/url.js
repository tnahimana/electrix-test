require('../modules/web.url');
require('../modules/web.url.to-json');
require('../modules/web.url-search-params');
require('../modules/web.url-search-params.size');
var path = require('../internals/path');

module.exports = path.URL;
