module.exports = require('../full/self');
