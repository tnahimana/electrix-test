module.exports = require('../full/escape');
