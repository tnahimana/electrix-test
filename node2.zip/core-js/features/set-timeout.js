module.exports = require('../full/set-timeout');
