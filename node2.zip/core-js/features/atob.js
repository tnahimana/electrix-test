module.exports = require('../full/atob');
