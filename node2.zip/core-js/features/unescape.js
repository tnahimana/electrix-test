module.exports = require('../full/unescape');
