module.exports = require('../full/queue-microtask');
