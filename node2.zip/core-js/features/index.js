module.exports = require('../full');
