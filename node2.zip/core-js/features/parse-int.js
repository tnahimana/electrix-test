module.exports = require('../full/parse-int');
