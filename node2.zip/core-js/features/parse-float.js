module.exports = require('../full/parse-float');
