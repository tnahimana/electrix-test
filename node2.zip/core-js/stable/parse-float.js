var parent = require('../es/parse-float');

module.exports = parent;
