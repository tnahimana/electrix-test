var parent = require('../es/parse-int');

module.exports = parent;
