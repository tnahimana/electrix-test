module.exports = typeof navigator != 'undefined' && String(navigator.userAgent) || '';
