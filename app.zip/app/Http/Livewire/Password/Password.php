<?php

namespace App\Http\Livewire\Password;

use App\Models\User;
use Livewire\Component;
use App\Models\MobileUser;
use Illuminate\Support\Facades\Hash;

class Password extends Component
{
    public $mobile_email;
    public $mobile_emails;
    public $mobile_phone;
    public $mobile_phones;
    public $selection;
    public $password;
    public $confirm_password;
    public $require_email = '';
    public $require_phone = '';
    
    public function render()
    {
        $users = MobileUser::where('admin_role', '!=', 'allowed')->get();
        foreach ($users as $item) {
            $mobile_emails[] = [
                'email' => $item->email

            ];
            $this->mobile_emails = $mobile_emails;
        }
        foreach ($users as $item) {
            $mobile_phones[] = [
                'phone' => $item->phone

            ];
            $this->mobile_phones = $mobile_phones;
        }
        return view('livewire.password.password',[
            'emails' => $this->mobile_emails,
            'phones' => $this->mobile_phones,
        ]);
    }

    protected function rules()
    {
        return [
            
            'mobile_email' => $this->require_email,
            'mobile_phone' => $this->require_phone,
            'selection' => 'required',
            'password' => 'required | min:8',
            'confirm_password' => 'required | min:8 | same:password',
        ];
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
        if($this->selection == 'email'){
            $this->require_email = 'required';
        }elseif($this->selection == 'phone'){
            $this->require_phone = 'required';
        }
    }

    public function save(){
        $validatedData = $this->validate();
        $this->updateUser();
    }

    public function updateMobileUser(){
        $email = MobileUser::where('email', $this->mobile_email)->orWhere('phone', $this->mobile_phone)->first();
        $user = MobileUser::where('email',$this->mobile_email)->orWhere('phone', $this->mobile_phone)->update([
            'password' => Hash::make($this->password)
        ]);
        if($user){
            return $email;
        }else{
            return redirect()->to('password-reset')->with('error', 'Oops, Something went wrong!');
        }
    }
    
    public function updateUser(){
        $email = $this->updateMobileUser()->email; 
        $user = User::where('email', $email)->update([
            'password' => Hash::make($this->password)
        ]);
        if ($user) {
            return redirect()->to('password-reset')->with('success', 'Password Updated successfully!');
        } else {
            return redirect()->to('password-reset')->with('error', 'Oops, Something went wrong!');
        }
    }
}