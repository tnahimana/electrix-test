<?php

namespace App\Http\Livewire\Schedule;

use Livewire\Component;
use App\Models\Schedule;
use App\Models\MobileUser;
use Illuminate\Support\Str;
use App\Models\ElectrixMeter;

class ScheduleCreate extends Component
{
    public $mobile_users;
    public $mobile_user;
    public $electrix_meters;
    public $electrix_meter;
    public $cost;
        
    public function render()
    {
        $users = MobileUser::get();
        foreach($users as $item){
            $mobile_users[] = [
                'phone' => $item->phone,
                'id' => $item->id

            ];
            $this->mobile_users = $mobile_users;
        }
        $electrixmeters = ElectrixMeter::get();
        foreach($electrixmeters as $item){
            $electrix_meters[] = [
                'meter_number' => $item->electrix_meter_number,
                'id' => $item->id,

            ];
            $this->electrix_meters = $electrix_meters;
        }
        return view('livewire.schedule.schedule-create',[
            'users' => $this->mobile_users,
            'electrixmeters' => $this->electrix_meters,
        ]);
    }

    protected $rules = [
      'mobile_user' => 'required',  
      'electrix_meter' => 'required',  
      'cost' => 'required | numeric | min: 1000',  
    ];

    public function updated($propertyName){
        return $this->validateOnly($propertyName);
    }

    public function save(){
        $validatedData = $this->validate();
        $schedule = Schedule::create([
            'uuid' => Str::uuid(),
            'mobile_user_id' => $this->mobile_user,
            'electrix_meter_id' => $this->electrix_meter,
            'token_cost' => $this->cost
        ]);
        return redirect()->to('/schedule-sale')->with('success', 'Sale Scheduled Successfully!');
    }

}