<?php

namespace App\Http\Livewire\Agent;

use App\Models\Cell;
use App\Models\Agents;
use App\Models\Sector;
use App\Models\Address;
use App\Models\Village;
use Livewire\Component;
use App\Models\District;
use App\Models\Document;
use App\Models\Province;

class AgentUpdate extends Component
{
    public $firstname;
    public $middlename;
    public $lastname;
    public $phone;
    public $province;
    public $prov;
    public $district;
    public $dist;
    public $sector;
    public $sect;
    public $cell;
    public $cel;
    public $village;
    public $vil;
    public $ids;
    public $zone;
    public $address;

    public function render()
    {
        return view('livewire.agent.agent-update',[
            'document' => Document::get(),
            'provinces' => Province::get(),
            'districts' => District::where('province_id', $this->province)->get(),
            'sectors' => Sector::where('district_id', $this->district)->get(),
            'cells' => Cell::where('sector_id', $this->sector)->get(),
            'villages' => Village::where('cell_id', $this->cell)->get(),
        ]);
    }

    public function mount($id){
        $agent = Agents::find($id);
        $this->ids = $id;
        $this->firstname = $agent->firstname;
        $this->middlename = $agent->middlename;
        $this->lastname = $agent->lastname;
        $this->phone = $agent->phone;
        $this->zone = $agent->agent_location;
        $this->address = $agent->address->office_address;
        $this->prov = $agent->address->province->province;
        $this->dist = $agent->address->district->district;
        $this->sect = $agent->address->sector->sector;
        $this->cel = $agent->address->cell->cell;
        $this->vil = $agent->address->village->village;
    }

    protected $rules = [
        'province' => 'required',
        'district' => 'required',
        'sector' => 'required',
        'cell' => 'required',
        'village' => 'required',
        'zone' => 'required | alpha',
        'address' => 'required',
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function save($id){
        $validatedData = $this->validate();
        $this->phone($this->phone, $id);
        $this->addressStore($id);
        $this->dispatchBrowserEvent('hide-form',['success' => 'Agent Info updated successfully!']);
        return redirect()->to('/agents/'. $id)->with('success', 'Agent Info updated successfully!');
    }

    public function addressStore($id){
        $agent = Agents::find($id);
        Address::where('id', $agent->address_id)->update([
            'province_id' => $this->province,
            'district_id' => $this->district,
            'sector_id' => $this->sector,
            'cell_id' => $this->cell,
            'village_id' => $this->village,
            'office_address' => $this->address,
        ]);
        return true;
    }

    public function phone($phone,$id){
        $admin = Agents::where('phone', $phone)->first();
        if($admin != null){
            $validatedData = $this->validate([
                'phone' => 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
            ]);
            return $validatedData;
        }else{
            $validatedData = $this->validate([
                'phone' => 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/|min:10 | unique:agents',
            ]);
            Agents::find($id)->update([
                'phone' => $this->phone, 
            ]);
            return $validatedData;
        }
    }
}
