<?php

namespace App\Http\Livewire\Auth;

use App\Models\User;
use Livewire\Component;
use Illuminate\Support\Facades\Hash;

class Login extends Component
{
    public $email;
    public $password;
    public $remember;

    public function render()
    {
        return view('livewire.auth.login');
    }

    protected $rules = [
        'email' => 'required|email',
        'password' => 'required',
    ];

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
    }

    public function login()
    {
        $validatedData = $this->validate();
        $this->loginUser();
    }

    public function loginUser()
    {
        $user = User::where('email', $this->email)->first();
        if($user == "")
        {
            session()->flash('error', 'Wrong email or password!');
            return redirect('/login')->with('error', 'Wrong email or password!'); 
        }
        elseif($user->role->admin != "")
        {
            if($user->role->admin->account_status == 'Active'){
                $this->auth($user);
            }
            else{
                return back()->with('error', 'Your account is inactive, 
                Contact Admin for further assistance');
            }
        }
        // elseif($user->role->client != "")
        // {
        //     if($user->role->client->account_status == 'Active'){
        //         $this->auth($user);
        //     }
        //     else{
        //         return back()->with('error', 'Your account is inactive, 
        //         Contact Admin for further assistance');
        //     }
        // }
        elseif($user->role->agent != "")
        {
            if($user->role->agent->account_status == 'Active'){
                $this->auth($user);
            }
            else{
                return back()->with('error', 'Your account is inactive, 
                Contact Admin for further assistance');
            }
        }
        else
        {
            return back()->with('error', 'Your account is inactive, 
            Contact Admin for further assistance');
        }
    }

    public function auth($user){
        $token = $user->createToken('myapptoken')->plainTextToken;

               if(!auth()->guard('web')->attempt(['email' => $this->email, 'password' => $this->password],$this->remember))
               {
                    return redirect('/login')->with('error','Wrong email or password!');
               }
               elseif(auth()->guard('web')->attempt(['email' => $this->email, 'password' => $this->password],$this->remember))
               {
                $new_session_id = \Session::getId(); //get new session_id after user sign in

                    if ($user->session_id != '') {
                        $last_session = \Session::getHandler()->read($user->session_id);

                        if ($last_session) {
                            if (\Session::getHandler()->destroy($user->session_id)) {

                            }
                        }
                    }
                    User::where('id', $user->id)->update(['session_id' => $new_session_id]);
                    $user = auth()->guard('web')->user();
                    if($user)
                    {
                        $device = \DeviceTracker::detectFindAndUpdate();
                        return redirect('/dashboard');  
                    }  
                }
    }
}