module.exports = {
  atom: 'atom',
  Brackets: 'brackets',
  code: 'code',
  'code-insiders': 'code-insiders',
  codium: 'codium',
  vscodium: 'vscodium',
  emacs: 'emacs',
  gvim: 'gvim',
  'idea.sh': 'idea',
  'phpstorm.sh': 'phpstorm',
  'pycharm.sh': 'pycharm',
  'rubymine.sh': 'rubymine',
  sublime_text: 'subl',
  vim: 'vim',
  'webstorm.sh': 'webstorm',
  'goland.sh': 'goland',
  'rider.sh': 'rider'
}
