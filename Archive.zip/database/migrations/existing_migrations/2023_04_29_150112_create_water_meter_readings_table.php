<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('water_meter_readings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('wasac_meter_id')->unique()->constrained()->onDelete('cascade');
            $table->unsignedBigInteger('previous_invoice_readings');
            $table->unsignedBigInteger('current_invoice_readings');
            $table->string('unpaid_invoice_readings');
            $table->string('management_type')->deault('self');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('water_meter_readings');
    }
};