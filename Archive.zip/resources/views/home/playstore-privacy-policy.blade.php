<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Electrix Ltd</title>
  <meta name="keywords" content="Electrix,Smart Metering,Energy Solutions, Vending Software, Rwanda Energy">
  <meta name="author" content="Electrix Ltd">
  <meta name="description" content="Electrix Ltd is a fintech company that is specialized in developping Mobile and Web applications designed to solve problems arising in Rwandan energy sector">
  <meta name="author" content="Electrix Ltd">

  <!-- Favicons -->
  <link href="{{ asset('web/assets/img/electrix-login.png') }}" rel="shortcut icon">
  <link href="{{ asset('web/assets/img/electrix-login.png') }}" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="{{ asset('web/assets/vendor/aos/aos.css') }}" rel="stylesheet">
  <link href="{{ asset('web/assets/vendor/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">
  <link href="{{ asset('web/assets/vendor/bootstrap-icons/bootstrap-icons.css') }}" rel="stylesheet">
  <link href="{{ asset('web/assets/vendor/boxicons/css/boxicons.min.css') }}" rel="stylesheet">
  <link href="{{ asset('web/assets/vendor/glightbox/css/glightbox.min.css') }}" rel="stylesheet">
  <link href="{{ asset('web/assets/vendor/remixicon/remixicon.css') }}" rel="stylesheet">
  <link href="{{ asset('web/assets/vendor/swiper/swiper-bundle.min.css') }}" rel="stylesheet">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- Template Main CSS File -->
  <link href="{{ asset('web/assets/css/style.css') }}" rel="stylesheet">
  @livewireStyles

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center">

      {{-- <h1 class="logo me-auto"><a href="/">Electrix</a></h1> --}}

      <nav id="navbar" class="navbar">
        {{-- <ul> --}}
          {{-- <li><a class="nav-link scrollto active" href="/">Home</a></li> --}}
          {{-- <li><a class="nav-link scrollto" href="/privacy-policy">Privacy Policy</a></li> --}}
          {{-- <li><a class="nav-link scrollto" href="/terms&conditions">Terms & Conditions</a></li> --}}
          {{-- <li><a class="getstarted scrollto" href="/login" target="_blank">Sign In</a></li> --}}
        {{-- </ul> --}}
        {{-- <i class="bi bi-list mobile-nav-toggle"></i> --}}
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="#">Home</a></li>
          <li>Privacy Policy</li>
        </ol>
        <h2>Privacy Policy</h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page">
      <div class="container">
        <p>At Electrix Ltd, we take your privacy seriously. This privacy policy explains what information we collect, how we use it, and how we protect it.</p>
        <h5>Information We Collect</h5>
        <p>We collect two types of information from you when you use our application:</p>
        <p>1. Personal Information: We collect personal information when you create an account with us, such as your name and email address. We use this information to identify you and provide you with our services.</p>
        <p>2. Non-Personal Information: We collect non-personal information about your device and usage of our application, such as your device model, operating system, and app usage statistics. We use this information to improve our services and optimize our application for your device.</p>
        <h5>Phone Access</h5>
        <p>Our application requires access to your phone to initiate payment on our accepted payment method(Airtel Pay and MoMo Pay) and we may read your phone number for proccessing some transaction and account verification purposes. We only access your phone number and do not access any other personal data or call history on your device.</p>
        <h5>How We Use Your Information</h5>
        <p>We use your information to:</p>
        <p>1. Provide and improve our services to you</p>
        <p>2. Customize our services to your preferences and needs</p>
        <p>3. Communicate with you about updates and changes to our services</p>
        <p>4. Monitor and analyze usage of our application</p>
        <p>5. Comply with legal requirements and protect our rights</p>
        <h5>Data Storage and Security</h5>
        <p>We store your personal and non-personal information on our secure servers, which are located in the United States. We take appropriate measures to protect your information from unauthorized access, use, or disclosure. However, please be aware that no security measures are perfect or impenetrable, and we cannot guarantee the security of your information.</p>
        <h5>Sharing of Data</h5>
        <p>We do not share your personal information with third parties, except as required by law or to protect our rights. We may share non-personal information with third-party service providers for the purposes of improving our services and analyzing usage of our application.</p>
        <h5>User Rights</h5>
        <p>You have the right to access, edit, or delete your personal information from our application at any time. You can do so by logging into your account and accessing your profile settings.</p>
        <h5>Updates to Policy</h5>
        <p>We may update this privacy policy from time to time to reflect changes in our services or legal requirements. We will notify you of any material changes to this policy by email or through our application.</p>
        <h5>Contact Us</h5>
        <p>If you have any questions or concerns about this privacy policy, please contact us at <strong>theonesten1@gmail.com / support@electrix.rw</strong></p>
        <p>Effective Date: March 30, 2023.</p>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Electrix</h3>
            <p>
              KN  82 Street <br>
              Nyarugenge, Kigali<br>
              Rwanda <br>
              <strong>Phone:</strong> +250 785 257 667<br>
              <strong>Email:</strong> info@electrix.rw<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="/">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="/">Products</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Smart Metering</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Mobile Apps</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">24/7 Help & Support</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
            <p>Follow us on our social media platforms</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-youtube"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright <strong><span>Electrix Ltd</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/ -->
        &copy; Inc <a href="/">@if(date('Y') > 2022) 2022 - {{ date('Y') }} @else {{ date('Y') }} @endif</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="{{ asset('web/assets/vendor/aos/aos.js') }}"></script>
  <script src="{{ asset('web/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('web/assets/vendor/glightbox/js/glightbox.min.js') }}"></script>
  <script src="{{ asset('web/assets/vendor/isotope-layout/isotope.pkgd.min.js') }}"></script>
  <script src="{{ asset('web/assets/vendor/swiper/swiper-bundle.min.js') }}"></script>
  <script src="{{ asset('web/assets/vendor/waypoints/noframework.waypoints.js') }}"></script>
  <script src="{{ asset('web/assets/vendor/php-email-form/validate.js') }}"></script>

  <!-- Template Main JS File -->
  <script src="{{ asset('web/assets/js/main.js') }}"></script>
  <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
  @livewireScripts

</body>

</html>