<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Reset Password</h2>
                    </div>

                    <div class="intro-y box mt-5">

                            <div id="inline-form" class="p-5">
                                <div class="flex flex-wrap -mx-3 mb-2">
                                    <div class="w-full md:w-1/3 px-3 md:mb-0">
                                            <select style="height: 50px" id="input-state-3" wire:model="selection" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('selection') border-theme-6 @elseif($selection != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Search Type --</option>
                                                <option value="email">Search by Email</option>
                                                <option value="phone">Search by Phone</option>
                                            </select>
                                            @error('selection')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                    </div>
                                    @if ($selection == 'email')
                                        <div class="w-full md:w-2/3 px-3 md:mb-0">
                                            <x-simple-select
                                                name="mobile_email"
                                                id="mobile_email"
                                                :options="$mobile_emails"
                                                value-field='email'
                                                text-field='email'
                                                placeholder="Select User Email"
                                                search-input-placeholder="Select User Email"
                                                :searchable="true"
                                                id="input-state-3"
                                                wire:model="mobile_email"
                                                class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            />
                                            @error('mobile_email')
                                                <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    @elseif($selection == 'phone')
                                        <div class="w-full md:w-2/3 px-3 md:mb-0">
                                            <x-simple-select
                                                name="mobile_phone"
                                                id="mobile_phone"
                                                :options="$mobile_phones"
                                                value-field='phone'
                                                text-field='phone'
                                                placeholder="Select User Phone"
                                                search-input-placeholder="Select User Phone"
                                                :searchable="true"
                                                id="input-state-3"
                                                wire:model="mobile_phone"
                                                class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                            />
                                            @error('mobile_phone')
                                                <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    @else
                                        <div class="w-full md:w-2/3 px-3">
                                            <section>
                                                <select style="height: 50px" disabled id="input-state-3" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                    py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 border-theme-6"
                                                >
                                                    <option value="" selected>No search type selected</option>
                                                </select>
                                            </section>
                                        </div>
                                    @endif

                                </div>
                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Password</label>
                                            <input style="height: 50px" id="input-state-1" wire:model="password" type="password" class="form-control @error('password') border-theme-6 @elseif($password != "") border-theme-9 @enderror" placeholder="Password...">
                                            @error('password')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <label for="input-state-1" class="form-label">Confirm Password</label>
                                            <input style="height: 50px" id="input-state-1" wire:model="confirm_password" type="password" class="form-control @error('confirm_password') border-theme-6 @elseif($confirm_password != "") border-theme-9 @enderror" placeholder="Confirm Password...">
                                            @error('confirm_password')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                                <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">
                                        <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> Submit <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                </div>

                        </div>

                    </div>

                </div>
            </form>
        </div>

    </div>
</div>