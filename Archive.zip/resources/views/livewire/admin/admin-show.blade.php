<div class="content" id="center">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                    <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Admin Information</h2>
                    @if(auth()->user()->role->name == 'super_admin')
                    <div class="mt-3 hidden md:block mr-6">
                        <div class="preview">
                            @if(auth()->user()->id != $admin->id)
                                @if($admin->account_status == 'Inactive')
                                <button wire:click="activate({{ $admin->id }})" type="button" style="background-color: green" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                @elseif($admin->account_status == 'Active')
                                <button wire:click="suspend({{ $admin->id }})" type="button" style="background-color: red" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                @endif
                                @if($mobile_role != "")
                                    @if($mobile_role->extra_role == 'blocked')
                                        <button wire:click="allowApp()" type="button" style="background-color: blue" class="btn btn-rounded-danger w-24 mr-1 mb-2">Allow App</button>
                                    @else
                                        <button wire:click="blockApp()" type="button" style="background-color: orange" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend App</button>
                                    @endif
                                @endif
                            @endif
                            <a href="/admins/{{ $admin->id }}/edit" class="btn btn-rounded-primary w-24 mr-1 mb-2">Update</a>
                        </div>
                    </div>
                    @endif
                </div>

                <div class="intro-y box mt-5">
                
                    <div id="inline-form" class="p-5">

                        <div class="preview sm:mr-5 sm:ml-5">
                            <div class="intro-y box sm:px-5 pt-5 mt-1">
                                <div class="flex flex-col lg:flex-row border-b border-gray-200 dark:border-dark-5 pb-5 -mx-5">
                                    <div class="flex flex-2 sm:px-5 items-center justify-center lg:justify-start">
                                        @if($showImage)
                                            <form action="POST" wire:submit.prevent="upload({{ $admin->id }})">
                                                <div class="intro-y box -mt-1" style="border-top: 2px solid rgb(17, 17, 134)">

                                                    <div class="intro-y flex items-center border-b border-gray-200 dark:border-dark-5 pb-4">
                                                        <h2 class="text-sm font-medium mr-auto mt-4 ml-6">Update Profile</h2>
                                                    </div>

                                                    <div id="inline-form" class="p-5">

                                                            <div class="w-full md:w-full px-3 mb-0 md:mb-0">
                                                                <div class="w-full md:w-full" wire:loading> 
                                                                    <div class="alert alert-success-soft show flex items-center mb-2 w-full" role="alert" wire:target="image" wire:loading>
                                                                        <i class="fas fa-spinner w-6 h-3 mr-2"></i> Uploading...
                                                                    </div>
                                                                </div>
                                                                    
                                                                <div class="md:mr-2">
                                                                    @if(!$image)
                                                                    <input id="input-state-1" wire:model="image" type="file" class="form-control" placeholder="image..." accept="image/*">
                                                                    @elseif($image)
                                                                    <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                                        <img alt="{{ $admin->fistname }}"  class="rounded-full" src="{{ $image->temporaryUrl() }}">
                                                                        @if(!$showImage)
                                                                            <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                                        @endif
                                                                    </div>
                                                                    @endif
                                                                    @error('image')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                        <div id="input-state"  class="p-3 flex flex-wrap items-end justify-end">
                                                            <button wire:click="resetImage" style="background-color:red" type="button" class="btn btn-rounded-danger w-20 mt-3 pr-4 pl-4 mr-2">Reset</button>
                                                            <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-rounded-primary w-20 mt-3 pr-4 pl-4">upload</button>
                                                        </div>
                                                        
                                                    </div>
                                                        
                                                </div>
                                            </form>
                                        @else
                                            <div class="w-20 h-20 sm:w-24 sm:h-24 flex-none lg:w-32 lg:h-32 image-fit relative">
                                                <img alt="{{ $admin->fistname }}" class="rounded-full" src="@if($admin->image_id != null) {{ asset($admin->image->img_url) }} @else {{ asset('dist/images/profile-4.jpg') }} @endif">
                                                @if(!$showImage)
                                                    @if(auth()->user()->id == $admin->id)
                                                        <div wire:click="addImage" class="absolute mb-1 mr-1 flex items-center justify-center bottom-0 right-0 bg-theme-1 rounded-full p-2"> <i class="w-4 h-3 text-white fas fa-camera"></i> </div>
                                                    @endif
                                                @endif
                                            </div>
                                            <div class="ml-5">
                                                <div class="w-24 sm:w-40 truncate sm:whitespace-normal font-medium text-lg">{{ $admin->firstname }}</div>
                                                <div class="text-gray-600 capitalize font-medium">{{ $admin->role->name }}</div>
                                            </div>
                                        @endif
                                    </div>
                                    @if($personalInfo)
                                        <div id="height"  class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Personal Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">First Name:</strong>{{ $admin->firstname }}</span>
                                                </div>
                                                @if($admin->middlename)
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Middle Name:</strong>{{ $admin->middlename }}</span>
                                                </div>
                                                @endif
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-user h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Last Name:</strong>{{ $admin->lastname }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-id-card h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">{{ $admin->document->document_type . " "}}Number:</strong>{{ $admin->document_number }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-venus-mars h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Gender:</strong>{{ $admin->gender }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($contactInfo)
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Contact Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-envelope h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Email:</strong>{{ $admin->email }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-phone-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Phone:</strong>{{ $admin->phone }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    @elseif($addressInfo)
                                        <div id="height" class="mt-6 lg:mt-0 flex-1 dark:text-gray-300 px-5 border-l border-gray-200 dark:border-dark-5 border-t lg:border-t-0 pt-5 lg:pt-0">
                                            <div class="font-medium text-center lg:text-left lg:mt-3">Address Details</div>
                                            <div class="flex flex-col sm:justify-start sm:items-start mt-4">
                                                <div class="truncate sm:whitespace-normal flex items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Province:</strong>{{ $admin->address->province->province }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">District:</strong>{{ $admin->address->district->district }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Sector:</strong>{{ $admin->address->sector->sector }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Cell:</strong>{{ $admin->address->cell->cell }}</span>
                                                </div>
                                                <div class="truncate sm:whitespace-normal flex mt-2 items-center"> 
                                                    <i class="fas fa-map-marker-alt h-3 w-4 mr-2"></i>
                                                    <span><strong class="mr-3 font-medium">Village:</strong>{{ $admin->address->village->village }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                                <div class="nav nav-tabs flex-col sm:flex-row justify-center lg:justify-start" role="tablist"> 
                                    <button wire:click="personalInfo" type="button" id="dashboard-tab" data-toggle="tab" data-target="#dashboard" class="py-4 sm:mr-8 @if($personalInfo) active @endif" role="tab" aria-controls="dashboard" aria-selected="true">Personal Info</button> 
                                    <button wire:click="contactInfo" type="button" id="account-and-profile-tab" data-toggle="tab" data-target="#account-and-profile" class="py-4 sm:mr-8 @if($contactInfo) active @endif" role="tab" aria-selected="false">Contact Info</button> 
                                    <button wire:click="addressInfo" type="button" id="activities-tab" data-toggle="tab" data-target="#activities" class="py-4 sm:mr-8 @if($addressInfo) active @endif" role="tab" aria-selected="false">Address Info</button> 
                                    @if(auth()->user()->role->name == 'super_admin')
                                    <div class="mt-3" id="hide">
                                        <div class="preview">
                                            @if(auth()->user()->id != $admin->id)
                                                @if($admin->account_status == 'Inactive')
                                                <button wire:click="activate({{ $admin->id }})" type="button" style="background-color: green; hover:border: 1px solid white;" class="btn btn-rounded-success w-24 mr-1 mb-2">Activate</button>
                                                @elseif($admin->account_status == 'Active')
                                                <button wire:click="suspend({{ $admin->id }})" type="button" style="background-color: red; hover:border: 1px solid white;" class="btn btn-rounded-danger w-24 mr-1 mb-2">Suspend</button>
                                                @endif
                                            @endif
                                            <a href="/admins/{{ $admin->id }}/edit" tyle="hover:border: 1px solid white" class="btn btn-rounded-primary w-24 mr-1 mb-2">Update</a>
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>    
</div>