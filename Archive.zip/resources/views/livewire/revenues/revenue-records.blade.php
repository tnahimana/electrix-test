<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y box mt-5">

                        <div id="inline-form" class="p-5">

                            <div class="preview mr-5 ml-5">

                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-10/12 px-3 md:mb-0">
                                        <div>
                                            <select id="input-state-3" wire:model="record_type" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700
                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('record_type') border-theme-6 @elseif($record_type != "") border-theme-9 @enderror"
                                            >
                                                <option value="" selected>-- Select Record Type --</option>
                                                <option value="Meter Revenues">Meter Revenues</option>
                                                <option value="Commussion Revenues">Commussion Revenues</option>
                                                <option value="Revenue Summary">Revenue Summary</option>
                                            </select>
                                            @error('record_type')
                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="w-full md:w-2/12 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2 flex flex-wrap items-end justify-end" style="margin-top: -20px">
                                            <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> Submit <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>
            </form>
            @if($record_type != "" && $showMeterRevenues)
                <div>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
                            <select class="w-20 form-select box mt-3 sm:mt-0" wire:model="perPage">
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="500">500</option>
                                <option value="{{ $count->count() }}">Other</option>
                            </select>
                             <div class="flex mt-5 sm:mt-0 ml-2">

                            </div>
                            <div class="hidden md:block mx-auto text-gray-600">

                            </div>
                            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                                    <input wire:model.debounce.100ms="search" type="text" class="form-control w-56 box pr-10 placeholder-theme-13" placeholder="Search...">
                                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i>
                                </div>
                            </div>
                        </div>
                        <!-- BEGIN: Data List -->
                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                            <table class="table table-report -mt-2">
                                <thead>
                                    <tr>
                                        <th class="whitespace-nowrap">S/N</th>
                                        <th class="whitespace-nowrap">Client Name</th>
                                        <th class="whitespace-nowrap">Sold By</th>
                                        <th class="whitespace-nowrap">Price</th>
                                        <th class="whitespace-nowrap">Quantity</th>
                                        <th class="whitespace-nowrap">Travel Expenses</th>
                                        <th class="whitespace-nowrap">Date</th>
                                        <th class="text-center whitespace-nowrap">Total</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @forelse($meter_sales as $item)

                                        <tr class="intro-x">
                                            <td class="w-20">
                                                {{ $i++ }}
                                            </td>
                                            <td>
                                                {{ $item->client->firstname ." ". $item->client->lastname }}
                                            </td>
                                            <td>
                                                {{ $item->user->admin->firstname ." ". $item->user->admin->lastname }}
                                            </td>
                                            <td>
                                                {{ $item->meter_cost }}
                                            </td>
                                            <td>
                                                {{ $item->quantity }}
                                            </td>
                                            <td>
                                                {{ $item->travel_expenses }}
                                            </td>
                                            <td style="font-size: 12px">
                                                {{ $item->created_at }}
                                            </td>
                                            <td class="table-report__action w-56">
                                                <div class="flex justify-center items-center">
                                                    {{ intVal($item->meter_cost) * intVal($item->quantity) - intVal($item->travel_expenses) }}
                                                    <div style="display: none">{{ $sum = $sum + (intVal($item->meter_cost) * intVal($item->quantity) - intVal($item->travel_expenses)) }}</div>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr class="intro-x">
                                            <td colspan="8" class="text-center">
                                                No record found!
                                            </td>
                                        </tr>
                                    @endforelse
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="2">Total Revenues</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <td class="flex justify-center items-center font-bold">{{ $sum }} Frw</td>
                                        </tr>
                                    </tfoot>
                            </table>
                        </div>
                        <!-- END: Data List -->
                        <!-- BEGIN: Pagination -->
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap items-center">
                            <ul class="pagination">
                            </ul>
                            <div class="pl-5 pr-5 pt-1 pb-1 box mt-3 sm:mt-0">
                                <ul class="pagination">
                                {!! $meter_sales->links() !!}
                                </ul>
                            </div>

                        </div>
                        <!-- END: Pagination -->
                    </div>
                </div>
            @elseif($showCommussionRevenues)
                <div>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-nowrap items-center mt-2">
                            <select class="w-20 form-select box mt-3 sm:mt-0" wire:model="perPage">
                                <option value="10">10</option>
                                <option value="25">25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="500">500</option>
                                <option value="{{ $count->count() }}">Other</option>
                            </select>
                             <div class="flex mt-5 sm:mt-0 ml-2">

                            </div>
                            <div class="hidden md:block mx-auto text-gray-600">

                            </div>
                            <div class="w-full sm:w-auto mt-3 sm:mt-0 sm:ml-auto md:ml-0">
                                <div class="w-56 relative text-gray-700 dark:text-gray-300">
                                    <input wire:model.debounce.100ms="search" type="text" class="form-control w-56 box pr-10 placeholder-theme-13" placeholder="Search...">
                                    <i class="w-4 h-4 absolute my-auto inset-y-0 mr-3 right-0" data-feather="search"></i>
                                </div>
                            </div>
                        </div>
                        <!-- BEGIN: Data List -->
                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                            <table class="table table-report -mt-2">
                                <thead>
                                    <tr>
                                        <th class="whitespace-nowrap">S/N</th>
                                        <th class="whitespace-nowrap">Client Name</th>
                                        <th class="whitespace-nowrap">Reg Meter Number</th>
                                        <th class="whitespace-nowrap">Electrix Meter Number</th>
                                        <th class="whitespace-nowrap">Token Cost</th>
                                        <th class="whitespace-nowrap">Units</th>
                                        <th class="whitespace-nowrap">Date</th>
                                        <th class="text-center whitespace-nowrap">Comussion Fee</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @forelse($meter_sales as $item)

                                        <tr class="intro-x">
                                            <td class="w-20">
                                                {{ $i++ }}
                                            </td>
                                            <td>
                                                {{ $item->mobileuser->firstname ." ". $item->mobileuser->lastname }}
                                            </td>
                                            <td>
                                                {{ $item->regmeter->reg_meter_number }}
                                            </td>
                                            <td>
                                                {{ $item->electrixmeter->electrix_meter_number }}
                                            </td>
                                            <td>
                                                {{ $item->initial_cost }}
                                            </td>
                                            <td>
                                                {{ $item->units }}
                                            </td>
                                            <td style="font-size: 12px">
                                                {{ $item->created_at }}
                                            </td>
                                            <td class="table-report__action w-56">
                                                <div class="flex justify-center items-center">
                                                    {{ intVal($item->initial_cost) * 0.05 }}
                                                    <div style="display: none">{{ $sum = $sum + (intVal($item->initial_cost) * 0.05) }}</div>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr class="intro-x">
                                            <td colspan="8" class="text-center">
                                                No record found!
                                            </td>
                                        </tr>
                                    @endforelse
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="2">Total Revenues</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <td class="flex justify-center items-center font-bold">{{ $sum }} Frw</td>
                                        </tr>
                                    </tfoot>
                            </table>
                        </div>
                        <!-- END: Data List -->
                        <!-- BEGIN: Pagination -->
                        <div class="intro-y col-span-12 flex flex-wrap sm:flex-row sm:flex-nowrap items-center">
                            <ul class="pagination">
                            </ul>
                            <div class="pl-5 pr-5 pt-1 pb-1 box mt-3 sm:mt-0">
                                <ul class="pagination">
                                {!! $meter_sales->links() !!}
                                </ul>
                            </div>

                        </div>
                        <!-- END: Pagination -->
                    </div>
                </div>
            @elseif($showOverallRevenues)
                <div>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <!-- BEGIN: Data List -->
                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                            <table class="table table-report -mt-2">
                                <thead>
                                    <tr>
                                        <th class="whitespace-nowrap">S/N</th>
                                        <th class="whitespace-nowrap">Sold Meters</th>
                                        <th class="whitespace-nowrap">Total Cost</th>
                                        <th class="whitespace-nowrap">Travel Expenses</th>
                                    </tr>
                                </thead>
                                <tbody style="display: none">
                                    <div style="display: none">
                                        {{ $quantity = 0 }}
                                        {{ $price = 0 }}
                                        {{ $expense = 0 }}
                                    </div>
                                    @forelse($saleRecord as $item)
                                        <tr class="intro-x">
                                            <td class="w-20">
                                                {{ $i++ }}
                                            </td>
                                            <td>
                                                {{ $quantity += $item->quantity }}
                                            </td>
                                            <td>
                                                {{ $price += intVal($item->quantity) * intVal($item->meter_cost) }}
                                            </td>
                                            <td>
                                                {{ $expense += intVal($item->travel_expenses) }}
                                            </td>
                                            <td class="table-report__action w-56">
                                                <div class="flex justify-center items-center">
                                                    {{ $price - $expense }}
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr class="intro-x">
                                            <td colspan="5" class="text-center">
                                                No record found!
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                                <tbody>
                                        <tr class="intro-x">
                                            <td class="w-20">
                                                #
                                            </td>
                                            <td>
                                                {{ $quantity }}
                                            </td>
                                            <td>
                                                {{ $price }} Frw
                                            </td>
                                            <td>
                                                {{ $expense }} Frw
                                            </td>
                                        </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="2">Total Revenues</th>
                                        <th></th>
                                        <td class="flex justify-center items-center font-bold text-green-500">{{ $price - $expense }} Frw</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <!-- END: Data List -->
                    </div>
                </div>
                <div>
                    <div class="grid grid-cols-12 gap-6 mt-5">
                        <!-- BEGIN: Data List -->
                        <div class="intro-y col-span-12 overflow-auto lg:overflow-visible">
                            <table class="table table-report -mt-2">
                                <thead>
                                    <tr>
                                        <th class="whitespace-nowrap">S/N</th>
                                        <th class="whitespace-nowrap">Purchased Units</th>
                                        <th class="whitespace-nowrap">Total Amount</th>
                                        {{-- <th class="whitespace-nowrap">Total Commussion</th> --}}
                                    </tr>
                                </thead>
                                <tbody style="display: none">
                                    <div style="display: none">
                                        {{ $units = 0 }}
                                        {{ $amount = 0 }}
                                        {{ $revenue = 0 }}
                                    </div>
                                    @forelse($commussion as $item)
                                        <tr class="intro-x">
                                            <td class="w-20">
                                                {{ $i++ }}
                                            </td>
                                            <td>
                                                {{ $units += $item->units }}
                                            </td>
                                            <td>
                                                {{ $amount += $item->initial_cost }}
                                            </td>
                                            <td>
                                                {{ $revenue += (intVal($item->initial_cost) * 0.05) }}
                                            </td>
                                        </tr>
                                    @empty
                                        <tr class="intro-x">
                                            <td colspan="5" class="text-center">
                                                No record found!
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                                <tbody>
                                        <tr class="intro-x">
                                            <td class="w-20">
                                                #
                                            </td>
                                            <td>
                                                {{ $units }} Kwh
                                            </td>
                                            <td>
                                                {{ $amount }} Frw
                                            </td>
                                            {{-- <td>
                                                {{ $revenue }} Frw
                                            </td> --}}
                                        </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="2">Total Commussion Revenues</th>
                                        <td class="flex justify-center items-center font-bold text-green-500">{{ $revenue }} Frw</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                        <!-- END: Data List -->
                    </div>
                </div>
            @endif
        </div>

    </div>
</div>