@extends('../layout/' . $layout)

@section('title')
    Register Sale | Electrix Vending
@endsection

@section('active-sale')
    side-menu--active
@endsection

@section('navigation')
    Register Sale
@endsection

@section('navigation-url')
    register-meter-sale
@endsection

@section('subcontent')
    @livewire('revenues.sale-register')
@endsection