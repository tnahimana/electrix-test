<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save({{ $client->id }})">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y col-span-12 lg:col-span-6">
                        <div id="progressbar-color" class="p-5">
                            <div class="progress mt-3">
                                <div class="progress-bar @if($showRegMeter) w-2/4 @else w-full @endif  bg-theme-9" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>

                    <div class="intro-y flex items-center mt-0 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">ADD @if($regtype) REG @elseif($wasactype) WASAC @endif Meter</h2>
                    </div>

                    <div class="intro-y box mt-5">

                        <div class="flex justify-center items-center sm:ml-4 text-gray-600">
                            <h2 class="text-sm font-medium mr-auto mt-4 ml-6">
                                @if($showRegMeter)
                                    @if($regtype) REG @elseif($wasactype) WASAC @endif Meter Information
                                @elseif($showElectrixMeter)
                                Electrix Meter Information
                                @endif
                            </h2>
                        </div>
                        
                        <div id="inline-form" class="p-5">
                            @if($showRegMeter)
                                <article class="container form-height">
                                    <div class="preview mr-5 ml-5">
                                        <div class="flex flex-wrap -mx-3 mb-2">
                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-1" class="form-label">Land UPI</label>
                                                    <input id="input-state-1" wire:model="upi" type="text" class="form-control @error('upi') border-theme-6 @elseif($upi != "") border-theme-9 @enderror" placeholder="-/--/--/--/----" maxlength="15">
                                                    @error('upi')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-2" class="form-label">@if($regtype) Reg @elseif($wasactype) Wasac @endif Meter Number</label>
                                                    <input id="input-state-2" wire:model="reg_meter_number" type="text" class="form-control @error('reg_meter_number') border-theme-6 @elseif($reg_meter_number != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="12">
                                                    @error('reg_meter_number')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Province</label>
                                                    <select id="input-state-3" wire:model="meter_province" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_province') border-theme-6 @elseif($meter_province != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Province --</option>
                                                        @foreach($meter_provinces as $item)
                                                            <option value="{{ $item->id }}">{{ $item->province }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_province')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location District</label>
                                                    <select id="input-state-3" wire:model="meter_district" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_district') border-theme-6 @elseif($meter_district != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select District --</option>
                                                        @foreach($meter_districts as $item)
                                                            <option value="{{ $item->id }}">{{ $item->district }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_district')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Sector</label>
                                                    <select id="input-state-3" wire:model="meter_sector" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_sector') border-theme-6 @elseif($meter_sector != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Sector --</option>
                                                        @foreach($meter_sectors as $item)
                                                            <option value="{{ $item->id }}">{{ $item->sector }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_sector')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Cell</label>
                                                    <select id="input-state-3" wire:model="meter_cell" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_cell') border-theme-6 @elseif($meter_cell != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Cell --</option>
                                                        @foreach($meter_cells as $item)
                                                            <option value="{{ $item->id }}">{{ $item->cell }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_cell')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Village</label>
                                                    <select id="input-state-3" wire:model="meter_village" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_village') border-theme-6 @elseif($meter_village != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Village --</option>
                                                        @foreach($meter_villages as $item)
                                                            <option value="{{ $item->id }}">{{ $item->village }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_village')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-1" class="form-label">Street Number</label>
                                                    <input id="input-state-1" wire:model="street" type="text" class="form-control @error('street') border-theme-6 @elseif($street != "") border-theme-9 @enderror" placeholder="KK 340 St" maxlength="15">
                                                    @error('street')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Required Meters</label>
                                                    <select id="input-state-3" wire:model="selected" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('selected') border-theme-6 @elseif($selected != "") border-theme-9 @enderror"
                                                    >
                                                        <option class="text-center" value="">-- Select Number of Meters --</option>
                                                        @for($i = 1; $i <= 10; $i++)
                                                            <option class="text-left text-lg" value="{{ $i }}">{{ $i <= 9 ? '0'.$i : $i }}</option>
                                                        @endfor
                                                        
                                                    </select>
                                                    @error('selected')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </article>
                            @elseif($showElectrixMeter)
                                <main class="container @if($selected < 3)form-height @endif">
                                    <div class="preview mr-5 ml-5">
                                        <div class="grid grid-flow-col gap-3">
                                            <div class="col-span-1">

                                                <div class="flex flex-wrap -mx-3 mb-2">
                                                    <div class="w-full md:w-4/5 px-3 mb-6 md:mb-0">
                                                        <div>
                                                            <label for="input-state-3" class="form-label">Required Meters</label>
                                                            <select id="input-state-3" wire:model="selected" class="form-select text-lg text-black box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500" disabled
                                                            >
                                                                <option class="text-center" value="">-- No Required Meters --</option>
                                                                @for($i = 1; $i <= 10; $i++)
                                                                    <option class="text-center text-lg" value="{{ $i }}">{{ $i }}</option>
                                                                @endfor
                                                                
                                                            </select>
                                                            @error('selected')
                                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                            @enderror
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-span-4">

                                                <div class="flex flex-wrap -mx-3 mb-2">
                                                    @if($wasactype)
                                                        <div class="flex flex-wrap -mx-3 mb-2">

                                                            <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                                                <div>
                                                                    <label for="input-state-3" class="form-label">Last Invoice <strong>m<sup>3</sup></strong> </label>
                                                                    <input id="input-state-1" wire:model="last_readings" type="text" class="form-control @error('last_readings') border-theme-6 @elseif($last_readings != "") border-theme-9 @enderror" placeholder="" maxlength="15">
                                                                    @error('last_readings')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                            <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                                                <div class="md:mr-2">
                                                                    <label for="input-state-1" class="form-label"> Current <strong>m<sup>3</sup></strong></label>
                                                                    <input id="input-state-1" wire:model="current_readings" type="text" class="form-control @error('current_readings') border-theme-6 @elseif($current_readings != "") border-theme-9 @enderror" placeholder="" maxlength="15">
                                                                    @error('current_readings')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                            <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                                                <div class="md:mr-2">
                                                                     <label for="input-state-1" class="form-label">Unpaid <strong>m<sup>3</sup></strong></label>
                                                                    <input id="input-state-1" wire:model="unpaid_readings" type="text" class="form-control @error('unpaid_readings') border-theme-6 @elseif($unpaid_readings != "") border-theme-9 @enderror" placeholder="" maxlength="15">
                                                                    @error('unpaid_readings')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                            <div class="w-full md:w-1/4 px-3 mb-6 md:mb-0">
                                                                <div class="md:mr-2">
                                                                     <label for="input-state-1" class="form-label">Management Type</label>
                                                                    <select id="input-state-3" wire:model="management_type" class="form-select text-sm text-black box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                                                                        <option class="text-center" value="">-- Select Type --</option>
                                                                        <option class="text-center text-lg" value="self">Self</option>
                                                                        <option class="text-center text-lg" value="other">Other</option>
                                                                        
                                                                    </select>
                                                                    @error('management_type')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                            </div>

                                                        </div>
                                                    @endif
                                                    <div class="w-full px-3 mb-6 md:mb-0">
                                                        <div class="md:mr-2">
                                                            <label for="input-state-2" class="form-label">Meter Number</label>
                                                                @if($selected == 1)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 2)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 3)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 4)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 5)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 6)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 7)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 8)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 @error('meter_number8') border-theme-6 @elseif($meter_number8 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number8')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 9)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 @error('meter_number8') border-theme-6 @elseif($meter_number8 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number8')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number9" type="text" class="form-control mt-3 @error('meter_number9') border-theme-6 @elseif($meter_number9 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number9')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 10)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 @error('meter_number8') border-theme-6 @elseif($meter_number8 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number8')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number9" type="text" class="form-control mt-3 @error('meter_number9') border-theme-6 @elseif($meter_number9 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number9')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number10" type="text" class="form-control mt-3 @error('meter_number10') border-theme-6 @elseif($meter_number10 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number10')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @endif
                                                        </div>
                                                    </div>
                                                    
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </main>
                            @endif
                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end -mt-2"> 
                                @if(!$showSubmit)
                                    @if(!$showRegMeter)        
                                    <button wire:click="previous" @if($hidePrevious) style="background-color: rgb(17, 17, 134)" disabled @endif type="button" class="btn btn-primary pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-angle-double-left w-4 h-4 mr-2 text-lg mb-2"></i> Previous  </button>
                                    @endif
                                    <button wire:click="back" style="background-color: red" type="button" class="btn btn-danger pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-backward w-4 h-4 mr-2 text-lg mb-2"></i> Back  </button>
                                    <button wire:click="next" style="background-color: rgb(17, 17, 134)" @if($hideNext) disabled @endif type="button" class="btn btn-primary pl-5 pr-5 mt-5 mb-2"> Next <i class="fas fa-angle-double-right w-4 h-4 ml-2 text-lg mb-2"></i></button>
                                @else
                                    <button wire:click="previous" style="background-color: rgb(17, 17, 134)" @if($hidePrevious) disabled @endif type="button" class="btn btn-primary pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-angle-double-left w-4 h-4 mr-2 text-lg mb-2"></i> Previous  </button>
                                    <button type="submit" class="btn btn-primary pl-5 pr-5 mt-5 mb-2" style="background-color: rgb(17, 17, 134)"><i class="h-4 text-lg mb-2"></i> Submit </button>
                                @endif
                            </div>
                        </div>
                        
                        
                    </div>
                    
                </div>
            </form>
        </div>

    </div>    
</div>