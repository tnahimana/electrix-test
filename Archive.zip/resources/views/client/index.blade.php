@extends('../layout/' . $layout)

@section('title')
    Clients | Electrix Vending
@endsection

@section('active-client')
    side-menu--active
@endsection

@section('navigation')
    Clients
@endsection

@section('navigation-url')
    clients
@endsection

@section('subcontent')
    @livewire('client.client-index')
@endsection