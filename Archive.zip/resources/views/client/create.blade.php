@extends('../layout/' . $layout)

@section('title')
    Register Client | Electrix Vending
@endsection

@section('active-client')
    side-menu--active
@endsection

@section('navigation')
    Register Client
@endsection

@section('navigation-url')
    create
@endsection

@section('subcontent')
    @livewire('client.client-create')
@endsection