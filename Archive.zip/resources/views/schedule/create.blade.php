@extends('../layout/' . $layout)

@section('title')
    Schedule Sale | Electrix Vending
@endsection

@section('active-schedule')
    side-menu--active
@endsection

@section('navigation')
    Schedule Sale
@endsection

@section('navigation-url')
    schedule-sale
@endsection

@section('subcontent')
    @livewire('schedule.schedule-create')
@endsection