@extends('../layout/' . $layout)

@section('title')
    Generate Invoice | Electrix Vending
@endsection

@section('active-meters')
    side-menu--active
@endsection

@section('navigation')
     Generate Invoice
@endsection

@section('navigation-url')
    generate-invoice
@endsection

@section('subcontent')
    @livewire('meter.generate-invoice')
@endsection