@extends('../layout/' . $layout)

@section('title')
    Dashbaord | Electrix Vending
@endsection

@section('dashbaord')
    side-menu--active
@endsection

@section('navigation')
   Energy Dashbaord
@endsection

@section('navigation-url')
    energy-dashboard
@endsection

@section('subcontent')
    @livewire('dashboard.energy-dashboard')
@endsection