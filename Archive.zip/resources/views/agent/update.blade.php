@extends('../layout/' . $layout)

@section('title')
    Update Agent Info | Electrix Vending
@endsection

@section('active-agent')
    side-menu--active
@endsection

@section('navigation')
    Update Agent Info
@endsection

@section('navigation-url')
    agents/{{ $agent }}/edit
@endsection

@section('subcontent')
    @livewire('agent.agent-update',['id' => $agent])
@endsection