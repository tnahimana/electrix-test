<?php

namespace App\Http\Livewire\Revenues;

use App\Models\Clients;
use App\Models\Installment;
use App\Models\Loan;
use App\Models\SaleRecord;
use Livewire\Component;

class SaleRegister extends Component
{
    public $client;
    public $clients = [];
    public $meter_cost;
    public $quantity;
    public $expenses;
    public $total_sales;
    public $payment_method;
    public $loan;
    public $installment;
    public $paid_amount;

    public function render()
    {
        $current_clients = Clients::with('address', 'address.sector', 'address.cell', 'address.village')->latest()->get();
        foreach($current_clients as $item){
            $clients[] = [
                'name' => $item->middlename ." ". $item->lastname ." ". $item->firstname ."  ~  ". $item->phone,
                'id'=> $item->id

            ];
            $this->clients = $clients;
        }
        return view('livewire.revenues.sale-register',[
            'clientInfo' => Clients::where('id', $this->client)->first(),
            'i' => 1,
        ]);
    }

    protected $rules = [
        'client' => 'required',
        'payment_method' => 'required',
        'quantity' => 'required | integer',
        'expenses' => 'required | integer | gt:999',
        'meter_cost' => 'required | integer | gt:39999 | lte:55000',
        'loan' => 'required',
        'installment' => 'required',
        'paid_amount' => 'required | integer | gt:39999',
    ];

    public function updated($propertyName){
        if($this->payment_method != "" && $this->validateOnly('client') && $this->validateOnly('meter_cost') && $this->validateOnly('quantity')&& $this->validateOnly('payment_method') && $this->validateOnly('expenses')){
            $this->total_sales = intval($this->meter_cost) * intval($this->quantity) - intval($this->expenses);
        }
        return $this->validateOnly($propertyName);
    }

    public function save(){
        if($this->payment_method != "Loaned"){
           $this->paid_amount = intval($this->meter_cost) * intval($this->quantity);
        }
        $validatedData = $this->validate();
        $record = SaleRecord::create([
            'user_id' => auth()->user()->id,
            'client_id' => $this->client,
            'meter_cost' => $this->meter_cost,
            'quantity' => $this->quantity,
            'travel_expenses' => $this->expenses,
            'payment_method' => $this->payment_method,
        ]);
        if($this->payment_method == 'Loaned'){
            $loan = Loan::create([
                'client_id' => $this->client,
                'loaned_meters' => $this->loan,
                'loan_amount' => intVal($this->total_sales) - intVal($this->paid_amount),
            ]);
            if($loan){
                for($x = 1; $x <= $this->installment; $x++){
                    if ($x == 1){
                      $first = $x .'<sup>st</sup> Installment';
                      $this->storeInstallment($loan->id ,  \Carbon\Carbon::now()->addMonth($x)->toDateString(), $x);
                    }
                    if($x == 2){
                       $second = $x . '<sup>nd</sup> Installment';
                       $this->storeInstallment($loan->id ,  \Carbon\Carbon::now()->addMonth($x)->toDateString(), $x);
                    }
                    if($x == 3){
                       $third = $x . '<sup>rd</sup> Installment';
                       $this->storeInstallment($loan->id ,  \Carbon\Carbon::now()->addMonth($x)->toDateString(), $x);
                    }
                    if($x == 4){
                        $fourth = $x . '<sup>th</sup> Installment';
                        $this->storeInstallment($loan->id ,  \Carbon\Carbon::now()->addMonth($x)->toDateString(), $x);
                    }
                    if($x == 5){
                        $fifth = $x . '<sup>th</sup> Installment';
                        $this->storeInstallment($loan->id ,  \Carbon\Carbon::now()->addMonth($x)->toDateString(), $x);
                    }
                    if($x == 6){
                        $sixth = $x . '<sup>th</sup> Installment';
                        $this->storeInstallment($loan->id ,  \Carbon\Carbon::now()->addMonth($x)->toDateString(), $x);
                    }
                }
            }
        }
        if($record){
            return redirect()->to('/register-meter-sale')->with('success', 'Sale Recorded Successfully!');
        }
    }

    public function storeInstallment($loan ,$month, $x){
        Installment::create([
            'loan_id' => $loan,
            'installment' => $x,
            'amount_to_pay'=>  intVal($this->paid_amount)/$this->installment,
            'due_date'=> $month,
        ]);
    }

}