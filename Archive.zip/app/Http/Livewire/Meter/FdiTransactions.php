<?php

namespace App\Http\Livewire\Meter;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\FdiTransaction;

class FdiTransactions extends Component
{
    use WithPagination;

    public $perPage = 10;
    public $search = '';
    
    public function render()
    {
        return view('livewire.meter.fdi-transactions',[
            'fditransactions' => FdiTransaction::search($this->search)->latest()->paginate($this->perPage),
            'i' => 1
        ]);
    }
}