<?php

namespace App\Http\Livewire\Dashboard;

use Livewire\Component;
use App\Models\WasacMeter;
use App\Models\ElectrixMeter;
use App\Models\WaterMeterReading;
use App\Models\WaterSale;

class WaterDashboard extends Component
{
    public $showInfo = true;
    public $showDetails = false;
    public $search_meter;
    public $meters_admin = [];
    public $selected_meter;
    public $metertype;
    public $meterrecords;
    public $showDashboard = false;
    public $electrix_meters;
    public $sales;
    public $perPage = 10 ;
    public $search = '';


    public function render()
    {
        $meters = ElectrixMeter::where('wasac_meter_id', '!=', null)->get();
        foreach($meters as $item){
            $meters_admin[] = [
                'meter_number' => $item->electrix_meter_number

            ];
            $this->meters_admin = $meters_admin;
        }
        $wasac_meters = WasacMeter::get();
        foreach($wasac_meters as $item){
            $meters_admin[] = [
                'meter_number' => $item->wasac_meter_number

            ];
            $this->meters_admin = $meters_admin;
        }
        return view('livewire.dashboard.water-dashboard',[
            'wasac_meters_admin' => WasacMeter::get()->count(),
            'wasac_meters_agent' => WasacMeter::where('user_id', auth()->user()->id)->get()->count(),
            'electrix_meters_admin' => ElectrixMeter::where('wasac_meter_id','!=', null)->get()->count(),
            'electrix_meters_agent' => ElectrixMeter::where('wasac_meter_id','!=', null)->where('user_id', auth()->user()->id)->get()->count(),
            'meters' => $this->meters_admin,
            'i' => 1,
        ]);
    }

    public function getInfo(){
        $this->render();
        return $this->showInfo = false;
    }

    public function hydrate(){
        return $this->render();
    }

    protected $rules = [
        'search_meter' => 'required'
    ];

    public function updated($propertyName){
       $this->validateOnly($propertyName);
    }

    public function search(){
        $this->validateOnly('search_meter');
        $wasac_meter =  WasacMeter::where('wasac_meter_number', $this->search_meter)->first();
        $electrix_meter =  ElectrixMeter::where('electrix_meter_number', $this->search_meter)->first();
        if($wasac_meter){
            $electrix_meter = ElectrixMeter::where('wasac_meter_id', $wasac_meter->id)->first();
            $this->electrix_meters = ElectrixMeter::where('wasac_meter_id', $wasac_meter->id)->get();
            $this->selected_meter = $electrix_meter;
            $this->metertype = 'electrix';
            $this->meterrecords = WaterMeterReading::where('wasac_meter_id', $wasac_meter->id)->first();
        }else if($electrix_meter){
            $this->selected_meter = $electrix_meter;
            $this->metertype = 'electrix';
            $this->electrix_meters = null;
            $this->meterrecords = WaterMeterReading::where('wasac_meter_id', $this->selected_meter->wasac_meter_id)->first();
        }
        $this->showDetails = true;
        $this->showDashboard = true;
        return $this->selected_meter;
    }

    public function showSales(){
        $this->sales = WaterSale::search($this->search)->with(['electrixmeter','wasacmeter','mobileuser'])->where('wasac_meter_id', $this->selected_meter->wasac_meter_id)->get();
        return $this->sales;
    }
}