<?php

namespace App\Http\Livewire\Dashboard;

use App\Models\Agents;
use App\Models\Clients;
use Livewire\Component;
use App\Models\RegMeter;
use App\Models\WasacMeter;
use App\Models\ElectrixMeter;
use App\Models\FdiTransaction;

class Dashboard extends Component
{
    public function render()
    {
        return view('livewire.dashboard.dashboard',[
            'sales_admin_energy' => ElectrixMeter::where('reg_meter_id', '!=', null)->count(),
            'sales_admin_water' => ElectrixMeter::where('wasac_meter_id', '!=', null)->count(),
            'sales_agent_energy' => ElectrixMeter::where('reg_meter_id', '!=', null)->where('user_id', auth()->user()->id)->count(),
            'sales_agent_water' => ElectrixMeter::where('wasac_meter_id', '!=', null)->where('user_id', auth()->user()->id)->count(),
            'client_admin' => Clients::count(),
            'client_agent' => Clients::where('register_id', auth()->user()->id)->count(),
            'agents' => Agents::count(),
            'reg_meters' => RegMeter::count(),
            'agent_reg_meters' => RegMeter::where('user_id', auth()->user()->id)->count(),
            'wasac_meters' => WasacMeter::count(),
            'agent_wasac_meters' => WasacMeter::where('user_id', auth()->user()->id)->count(),
            'location' => Agents::where('user_id', auth()->user()->id)->with('address')->first(), 
            'transactions_electrix' => FdiTransaction::where('transaction_type', 'electrix_electricity')->get()->count(),
            'transactions_reg' => FdiTransaction::where('transaction_type', 'electricity')->get()->count(),
            'transactions_airtime' => FdiTransaction::where('transaction_type', 'airtime')->get()->count(),
            'transactions_startime' => FdiTransaction::where('transaction_type', 'startimes_tv')->get()->count(),
            'transactions' => FdiTransaction::get()->count(),
        ]);
    }
}