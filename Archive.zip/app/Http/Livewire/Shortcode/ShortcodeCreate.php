<?php

namespace App\Http\Livewire\Shortcode;

use App\Models\Update;
use Livewire\Component;

class ShortcodeCreate extends Component
{
    public $name = "App Release Version";
    public $value;

    public function render()
    {
        return view('livewire.shortcode.shortcode-create');
    }

    protected $rules = [
        'name' => 'required | min:3',
        'value' => 'required | string | min:3 | unique:updates',
    ];

    public function updated($propertyName){
        return $this->validateOnly($propertyName);
    }

    public function save(){
        $validatedData = $this->validate();
        $update = Update::create([
            'name' => $this->name,
            'value' => $this->value,
        ]);
        if($update){
            $this->reset();
            return redirect()->to('/updates/create')->with('success', 'Update Released Successfuly!');
        }
    }
}
