<?php

namespace App\Http\Livewire\Agent;

use App\Models\Agents;
use Livewire\Component;
use Livewire\WithPagination;

class AgentIndex extends Component
{
    use WithPagination;

    public $perPage = 10;
    public $search = '';

    public function render()
    {
        return view('livewire.agent.agent-index',[
            'agents' => Agents::search($this->search)->paginate($this->perPage),
            'i' => 1,
        ]);
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updated(){
        $this->resetPage();
    }

    public function mount()
    {
        $this->resetPage();
    }
}
