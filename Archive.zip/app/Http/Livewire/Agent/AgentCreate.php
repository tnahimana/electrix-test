<?php

namespace App\Http\Livewire\Agent;

use App\Models\Cell;
use App\Models\Role;
use App\Models\User;
use App\Models\Agents;
use App\Models\Sector;
use App\Models\Address;
use App\Models\Village;
use Livewire\Component;
use App\Models\District;
use App\Models\Document;
use App\Models\Province;
use App\Models\MobileUser;
use Illuminate\Support\Facades\Hash;

class AgentCreate extends Component
{
    public $firstname;
    public $middlename;
    public $lastname;
    public $email;
    public $phone;
    public $gender;
    public $document_type;
    public $document_number;
    public $password;
    public $password_confirmation;
    public $province;
    public $district;
    public $sector;
    public $cell;
    public $village;
    public $address;
    public $zone;
    public $initial_doc = 16;
    public $doc;

    public function render()
    {
        return view('livewire.agent.agent-create',[
            'document' => Document::get(),
            'provinces' => Province::get(),
            'districts' => District::where('province_id', $this->province)->get(),
            'sectors' => Sector::where('district_id', $this->district)->get(),
            'cells' => Cell::where('sector_id', $this->sector)->get(),
            'villages' => Village::where('cell_id', $this->cell)->get(),
        ]);
    }

    protected function  rules(){ 
        return [
            'firstname'=> 'required | string | min:3 ',
            'middlename'=> 'string',
            'lastname'=> 'required | string | min:3 ',
            'gender'=> 'required',
            'email'=> 'required | email | unique:users',
            'document_type'=> 'required',
            'document_number'=> 'required | min:' . $this->initial_doc . '| unique:agents',
            'phone'=> 'required | numeric | regex:/^([0-9\s\-\+\(\)]*)$/| digits:10 | unique:agents',
            'password'=> 'required | min:8',
            'password_confirmation'=> 'required | min:8 | same:password',
            'province' => 'required',
            'district' => 'required',
            'sector' => 'required',
            'cell' => 'required',
            'village' => 'required',
            'zone' => 'required | alpha',
            'address' => 'required',
        ];
    }

    public function updated($propertyName)
    {
        $this->validateOnly($propertyName);
        if($this->document_type == 'NID'){
            $this->doc = 16;
            $this->initial_doc = $this->doc;
        }else{
            $this->doc = 8;
            $this->initial_doc = $this->doc;
        }
    }

    public function save()
    {
        $validatedData = $this->validate();
        $this->agentStore();
        $this->reset();
        return redirect('/agents')->with('success', 'Agent added Successfully!');
    }

    public function userStore(){
        $role = Role::where('name', 'agent')->first();
        User::create([
            'username' => $this->email,
            'email' => $this->email,
            'password' => Hash::make($this->password),
            'role_id' => $role->id,
        ]);
        $user = User::where('email', $this->email)->first();
        return $user->id;
    }

    public function adddressStore(){
        if(Address::where('village_id', $this->village)->first() == null){
            Address::create([
                'province_id' => $this->province,
                'district_id' => $this->district,
                'sector_id' => $this->sector,
                'cell_id' => $this->cell,
                'village_id' => $this->village,
                'office_address' => $this->address,
            ]);
        }
        $address = Address::where('village_id', $this->village)->first();
        return $address->id;
    }

    public function agentStore(){
        $user_id = $this->userStore();
        $this->mobileUserStore($user_id);
        $role = Role::where('name', 'agent')->first();
        $address_id = $this->adddressStore();
        Agents::create([
            'user_id' => $user_id,
            'role_id' => $role->id,
            'firstname' => $this->firstname,
            'middlename' => $this->middlename,
            'lastname' => $this->lastname,
            'email' => $this->email,
            'phone' => $this->phone,
            'gender' => $this->gender,
            'document_id' => $this->document_type,
            'document_number' => $this->document_number,
            'address_id' => $address_id,
            'password' => Hash::make($this->password),
            'agent_location' => $this->zone,
        ]);

        return session()->flash('success', 'Agent added Successfully!');
    }

    public function mobileUserStore($user){
        $mobile = MobileUser::create([
            'user_id' => $user,
            'firstname' => $this->firstname,
            'middlename' => $this->middlename,
            'lastname' => $this->lastname,
            'email' => $this->email,
            'phone' => $this->phone,
            'extra_role' => 'allowed',
            'password' => Hash::make($this->password),
        ]);
        return $mobile;
    }
}