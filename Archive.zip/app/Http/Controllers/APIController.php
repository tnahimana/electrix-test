<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class APIController extends Controller
{   
    public function index(){
        if(auth()->user()->role->name == 'super_admin' || auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'agent'){
            return view('meter.index');
        }else{
            return redirect()->to('/dashboard')->with('error', 'Unauthorized Access!');
        }
    }
}