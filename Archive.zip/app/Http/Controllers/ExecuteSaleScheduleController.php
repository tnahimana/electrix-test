<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\RegMeter;
use App\Models\Schedule;
use App\Models\MobileUser;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Models\ElectrixMeter;
use App\Models\FailedSchedule;
use App\Models\FdiTransaction;
use App\Models\VendTransaction;
use App\Models\NewApiTransaction;
use App\Models\SuccessfullSchedule;
use Illuminate\Support\Facades\Http;
use GrahamCampbell\ResultType\Success;
use Illuminate\Http\Client\RequestException;

class ExecuteSaleScheduleController extends Controller
{
    public $increament;
    private $wallet_balance;

    public function initiateSchedule(){
       $schedules = Schedule::where('status', false)->get();
       if($schedules->count() != 0){
           $balance = $this->balanceRequest();
           $trxSum = 0;
           foreach($schedules as $item){
            $trxSum += $item->token_cost;
           }
            if(intval($trxSum) <= intval($balance['data']['wallet_balance'])){
                foreach($schedules as $item){
                $amount = floatval($item->token_cost) - (floatval($item->token_cost)*0.05);
                if($this->queryMeter($item->electrixmeter->regmeter->reg_meter_number)['status_code'] == 1){
                    $phone = '25'.auth()->user()->admin->phone;
                    $regData = $this->generateRegToken($item->electrixmeter->regmeter->reg_meter_number, $item->amount, $phone, $item->electrix_meter_id);
                    $units = $regData['data']['units'];
                    $electrixData = $this->generateElectricityToken($item->electrixmeter->electrix_meter_number, $units);
                    if($electrixData['status_code'] == 1){
                        $storeSale = $this->saleStore($item->mobile_user_id ,$item->electrixmeter->regmeter->id, $item->electrix_meter_id, intval($item->token_cost)/ 0.95, intVal($item->token_cost)/ 0.95, $regData['data']['token'], $electrixData['data']['token'], $units, true);
                        if($storeSale){
                            $successStore = SuccessfullSchedule::create([
                                'uuid' => Str::uuid(),
                                'mobile_user_id' => $item->mobile_user_id,
                                'electrix_meter_id' => $item->electrix_meter_id,
                                'token_cost' => $item->token_cost,
                            ]);
                            $deleteSchedule = Schedule::where('id', $item->id)->delete();
                        }
                    }
                }else if($this->queryMeter($item->electrixmeter->regmeter->reg_meter_number)['status_code'] == 0){
                    $failedStore = FailedSchedule::create([
                        'uuid' => Str::uuid(),
                        'mobile_user_id' => $item->mobile_user_id,
                        'electrix_meter_id' => $item->electrix_meter_id,
                        'token_cost' => $item->token_cost,
                    ]);
                    $deleteSchedule = Schedule::where('id', $item->id)->delete();
                } 
                }
                return redirect()->to('/success');
            }else{
                return 'Insufficient balance';
            }
       }else{
        return redirect()->to('/error');
       }
    }

    public function queryMeter($meterNo){
        return $this->queryMeterNewApi($meterNo);  
    }


    public function generateElectricityToken($meterNo, $units){
       $amount = floatval($units) * 189;
       $meter = $this->validateElectrixMeter($meterNo);
       $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
       if($meter){
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            'CompanyName' => getenv('COMPANY_NAME'),
            'UserName' => getenv('USERNAME'),
            'PassWord' => getenv('PASSWORD'),
            'MeterID' => strVal($meter),
            'is_vend_by_unit' => "false",
            'Amount'=> strVal($amount)
        ]);
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', 'electrix_electricity')->where('resolve_status', false)->latest()->first();
        $updateTrx = FdiTransaction::where('id', $trx->id)
                                     ->update([
                                        'electrix_meter_number' => $meterNo,
                                        'resolve_status' => 1,
                                        'is_reg_status' => 1,
                                    ]);

        $data = [
                'status_code' => 1,
                'data' => [
                    'status' => true,
                    'msg' => $meter . ' # Token has been generated successfully!',
                    'response' => $response->json()[0],
                    'token' => $response->json()[0]['Token'],
                ]
            ];
        return $data;
       }else{
        $data = [
                'status_code' => 0,
                'data' => [
                    'status' => false,
                    'msg' => $meter . ' # meterno not doesn\'t exist',
                    'token' => null,
                ]
            ];
        return $data;
       }
    }

    public function generateRegToken($meterno, $amount, $customer_msisdn, $electrixId){
        $this->balanceRequest();
        $trx = $this->valitateTrx('electricity', $meterno);
        if(gettype($trx) == 'integer'){
            $data = [
                "status_code"=> 0, 
                "status_msg"=> "Meter not found: meter number " . $meterno . " does not exist or is not connected.", 
                "data"=> [
                    "amount"=> $amount
                ]
            ]; 
            return response($data,200);
        }else{
            if($this->retrieveVendTrx('electricity') != null){
                $returnData = $this->retrieveVendTrx('electricity')['trx_id'];
            }else{
                // $returnData = $this->executeTrx($trx['data']['trxId'], $meterno, $amount, $trx['data']['verticalId'], $trx['data']['deliveryMethods']['0']['id'], $this->removeFirstDigits($customer_msisdn, 2));
                $returnData = "/v2/vend/5c7349e3-f576-47f6-a3b7-05dffc064241/status/";
            }
            $this->storeVendTrx('electricity', $returnData);
            if(is_null($returnData)){
                $data = [
                    'status_code'=> 0,
                    'status_msg'=> 'Transction Barred for 3 minutes',
                    'data'=> []
                ];
                return response([$data],200);
            }else{
                sleep(1);
                $trx = substr(substr($returnData,3), 0, -1);
                $trxData = $this->retrieveTrx($trx);
                if($trxData['data']['spVendInfo']['voucher'] != null && $trxData['data']['spVendInfo']['units'] != null){
                    $this->storeNewApiData('electricity', $returnData, $trxData);
                    $data = [
                        "status_code"=> 1,
                        "status_msg"=> "ELEC VEND METER:" . $trxData['data']['customerAccountNumber'] . " TOKEN:". $trxData['data']['spVendInfo']['voucher'] ." UNITS: " . $trxData['data']['spVendInfo']['units'] . ", AMOUNT: " . $trxData['data']['spVendInfo']['trxAmount'] . " REF: .0000". now() . " Name:" . $trxData['data']['customerAccountName'] . " RECEIVER:" . $customer_msisdn . ". Your balance is:" . $this->wallet_balance,
                        "data"=> [
                            "units"=> $trxData['data']['spVendInfo']['units'],
                            "token"=>  $trxData['data']['spVendInfo']['voucher'],
                            "meterno"=> $trxData['data']['customerAccountNumber'],
                            "regulatory_fees"=> $trxData['data']['spVendInfo']['deductions'],
                            "receipt_no"=> $trxData['data']['spVendInfo']['receiptNo'],
                            "amount"=> $trxData['data']['spVendInfo']['trxAmount'],
                            "vat"=> $trxData['data']['spVendInfo']['vatNo'],
                            "customer_name"=> $trxData['data']['customerAccountName']
                        ],
                        "tstamp"=> now()->format('Y-m-d H:i:s')
                    ];
                    $this->deleteVendTrx('electricity', $returnData);
                    $this->fdiTransaction('electrix_electricity', $data, $customer_msisdn);
                    $updateSchedule = Schedule::where('electrix_meter_id', $electrixId)->update(['status' => true]);
                    return $data; 
                }
            }
        }
    }

     public function balanceRequest(){
        $balance =  $this->balanceRequestNewAPI()['data']['wallet_balance'];
        $this->wallet_balance = $balance;
        return $this->balanceRequestNewAPI(); 
    }

    public function validateElectrixMeter($meterNumber){
        $meter = ElectrixMeter::where('electrix_meter_number', $meterNumber)->with('regmeter')->first();
        if($meter != ''){
            return $meter->electrix_meter_number;
        }
        else{
            return null;
        }
    }

    public function fdiTransaction($trxType, $trxData, $phone){
        $data = FdiTransaction::create([
            'user_id' => auth()->user()->id,
            'customer_msisdn' => $phone,
            'transaction_type' => $trxType,
            'transaction_data' => json_encode($trxData),
            'resolve_status' => 0,
        ]);
        if($data){
            return $data;
        }
    }

    public function retrieveFdiTrancactions(){
        return response([
            'fdi_transactions' => FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', '!=', 'electrix_electricity')->latest()->get()
        ],200);
    }

    public function getFdiTrancactions($id){
        $fdi = FdiTransaction::find($id);
        return response([
            'fdi_transactions' => [
                'id' => $fdi->id,
                'user_id' => $fdi->user_id,
                'customer_msisdn' => $fdi->customer_msisdn,
                'transaction_type' => $fdi->transaction_type,
                'transaction_data' => $fdi->transaction_data,
                'resolve_status' => $fdi->resolve_status,
                'created_at' => $fdi->created_at->format('D,d-M-Y  g:i A'),
            ]
            ],200);
    }


    public function generateAuthToken(){
        $url = getenv('FDI_PAYMENT') . "/" . "auth";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->post($url, [
                'appId' => getenv('FDI_AP_ID'),
                'secret' => getenv('FDI_AP_SECRET'),
        ]);
        return $response->json()['data']['token'];
    }

    public function getFdiTrx(Request $request){
        $attrs = $request->validate([
            'trx_type'=> 'required'
        ]);
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', $attrs['trx_type'])->where('resolve_status', false)->latest()->first();
        return response([
            'trx' => $trx
        ],200);
    }

       public function failedPurchase($phone, $meter){
        $trx_type = "electrix_electricity";
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', $trx_type)->where('resolve_status', false)->where('electrix_meter_number', "null")->latest()->first();
        if(empty($trx)){
            return response([
                'trx' => null
            ],200);
        }else{
            $electrixMeter = $meter;
            $trx_id = $trx['id'];
            $trx = $trx['transaction_data'];
            if(explode(',', explode(':', $trx)[1])[0] == 0){
                return response([
                    'trx' => null
                ],200);
            }elseif(explode(',', explode(':', $trx)[1])[0] == 1){
                $trx = explode('":"', $trx);
                $trx = explode(' ', $trx[1]);
                $regMeter = explode('METER:', $trx[2])[1];
                $regToken = $this->cleanRegToken(explode('TOKEN:', $trx[3])[1]);
                $units = explode(',', $trx[5])[0];
                $cost = intval($trx[7]);
                $regId = RegMeter::where('reg_meter_number', $regMeter)->first()->id;
                $userId = MobileUser::where('user_id', auth()->user()->id)->first()->id;
                $electrixId = ElectrixMeter::where('electrix_meter_number', $electrixMeter)->first()->id;
                $electrixToken = $this->cleanEletrixToken($this->generateElectrixToken($meter, $units));
                $sale = $this->saleStore($userId,$regId, $electrixId, $cost, $cost, $regToken, $electrixToken, $units, true);
                if($sale){
                    return response([
                        'sale' => $sale
                    ],200);
                }

            }
        }
    }

    public function cleanEletrixToken($token){
      $remove_space = explode(" ",$token);
      $cleaned_token = implode('-', $remove_space);
      return $cleaned_token;
    }

    public function cleanRegToken($token){
        $separator = "-";
        $result = preg_replace('/(\d{4})(?=\d)/', '$1'.$separator, $token);
        return $this->cleanEletrixToken($result);
    }

    public function saleStore($userId,$regId, $electrixId, $initialCost, $tokenCost, $regToken, $electrixToken, $units, $subscriptionStatus){
        $sale = Sale::create([
            'mobile_user_id' => $userId,
            'reg_meter_id' => $regId,
            'electrix_meter_id' => $electrixId,
            'initial_cost' => ceil(intVal($initialCost)/0.95),
            'token_cost' => ceil(intVal($tokenCost)/0.95),
            'reg_meter_token' => $regToken,
            'electrix_meter_token' => $electrixToken,
            'units' => $units,
            'subscription_status'=> $subscriptionStatus,
        ]);
        return $sale;
    }

    public function generateElectrixToken($meter, $units){
       $amount = floatval($units) * 189;
       $meter = $this->validateElectrixMeter($meter);
       $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
       if($meter){
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            'CompanyName' => getenv('COMPANY_NAME'),
            'UserName' => getenv('USERNAME'),
            'PassWord' => getenv('PASSWORD'),
            'MeterID' => strVal($meter),
            'is_vend_by_unit' => "false",
            'Amount'=> strVal($amount)
        ]);
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', 'electrix_electricity')->where('resolve_status', false)->latest()->first();
        $updateTrx = FdiTransaction::where('id', $trx->id)
                                     ->update([
                                        'electrix_meter_number' => $meter,
                                        'resolve_status' => 1,
                                        'is_reg_status' => 1,
                                    ]);
        return $response->json()[0]['Token'];

       }
    }

    // FDI new API
    
     public function balanceRequestNewAPI(){
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/balance";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization'=> 'Bearer ' . $token
        ])->get($url);
        
        $data = [
            'status_code' => 1,
            'status_msg' => 'Success',
            'data' => [
                'wallet_balance' => $response['total'],
                'commission' => $this->commusionBalance($response),
                'cash' => floatval($response['total']) - floatval($this->commusionBalance($response)),
            ],
            'tstamp' => now()->format('Y-m-d H:i:s')
        ];
        return $data;
    }

    public function generateFdiAuthToken(){
        $url = getenv('FDI_NEW_ENDPOINT') . "/auth";
         $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            "api_key"=> getenv('FDI_API_KEY'),
            "api_secret"=> getenv('FDI_API_SECRET')
        ]);
        $token = $response->json()['data']['accessToken'];
        return $response = $token;
    }

    private function commusionBalance($data){
        $iterationCount = 0;
        $balances = 0;
        foreach ($data['data'] as $item) {
            $iterationCount++;
            if ($iterationCount === 1) {
                continue; // Skip the first iteration
            }
            $balance = floatval($item['balance']);
            $balances += $balance;
        }
        return $balances;
    }

    public function queryMeterNewAPI($meterNo){
        try {
           $token = $this->generateFdiAuthToken();
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/validate";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization'=> 'Bearer ' . $token
            ])->post($url,[
                "verticalId"=> "electricity",
                "customerAccountNumber"=> $meterNo
            ]);
            $data = [
                "status_code"=> 1,
                "status_msg"=> $response['data']['customerAccountNumber'],
                "data"=> [
                    "vend_min_amount"=> $response['data']['vendMin'],
                    "vend_max_amount"=> $response['data']['vendMax'],
                    "meterno"=> $meterNo,
                    "customer_name"=> $response['data']['customerAccountNumber']
                ],
                "tstamp"=> now()->format('Y-m-d H:i:s')
            ];
            return $data;
        } catch (RequestException $exception) {
            $statusCode = $exception->response->status();
            $errorMessage = $exception->response->json()['msg'];
            $data = [
                "status_code"=> 0,
                "status_msg"=> "Invalid meter number",
                "data"=> [
                    "meterno"=> $meterNo,
                    "customer_name"=> ""
                        ],
                "tstamp"=> now()->format('Y-m-d H:i:s')
            ];
            return $data;
        }
        
    }

    public function queryTrx(Request $request){
        $attrs = $request->validate([
            "limit"=> "required | int",
            "verticalId"=> "required | string",
            "fdate"=> "required | string",
            "tdate"=> "required | string",
            "customerAccountNumber"=> "",
            "trxId"=> "",
            "fromTime"=> "",
            "toTime"=> "",
        ]);
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/trx/history";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization'=> 'Bearer ' . $token
        ])->get($url,[
            "limit"=> $attrs['limit'],
            "verticalId"=> $attrs['verticalId'],
            "fdate"=> $attrs['fdate'],
            "tdate"=> $attrs['tdate'],
            "customerAccountNumber"=> $attrs['customerAccountNumber'],
            "trxId"=> $attrs['trxId'],
            "fromTime"=> $attrs['fromTime'],
            "toTime"=> $attrs['toTime'],
        ]);
        return $response->json();
    }

    private function removeFirstDigits($inputString, $numDigitsToRemove)
    {
        if (is_string($inputString) && strlen($inputString) > $numDigitsToRemove) {
            $resultString = substr($inputString, $numDigitsToRemove);
            return $resultString;
        } else {
            return "Invalid input or not enough characters to remove.";
        }
    }

    public function valitateTrx($trxType, $accountNumber){
        $token = $this->generateFdiAuthToken();
        try {
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/validate";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization'=> 'Bearer ' . $token
            ])->post($url,[
                "verticalId"=> $trxType,
                "customerAccountNumber"=> $accountNumber
            ]);
        return $response;
        } catch (RequestException $exception) {
            $statusCode = $exception->response->status();
            $errorMessage = $exception->response->json()['msg'];
            $data = [
                'statusCode' => $statusCode,
                'errorMessage' => $errorMessage
            ];
            return $statusCode;
        }
        
    }

    private function executeTrx($trxId, $customerAccountNumber, $amount, $verticalId, $deliveryMethodId, $deliverTo){
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/vend/execute";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization'=> 'Bearer ' . $token
        ])->post($url,[
            "trxId"=> $trxId,
            "customerAccountNumber"=> $customerAccountNumber,
            "amount"=> $amount,
            "verticalId"=> $verticalId,
            "deliveryMethodId"=> $deliveryMethodId,
            "deliverTo"=> $deliverTo,
            "callBack"=> "https/electrix.rw/electrix-meter-api/"
        ]);
        if(intval($response->getStatusCode()) == 500){
            return $response;
        }else{
            $response = $response->json(); 
            
            return $response['data']['pollEndpoint'];
        }
    }

    public function retrieveTrx($trxId){
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . $trxId;
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization'=> 'Bearer ' . $token
        ])->get($url);
        if($response['data']['pdtName'] == "EUCL Prepaid Electricity"){
            if($response['data']['spVendInfo']['voucher'] == null && $response['data']['spVendInfo']['units'] == null){
                return $this->retrieveTrx($trxId);
            }else{
                return $response; 
            }
        }else{
            return $response; 
        }
    }

    private function storeVendTrx($trx_type, $trx_id){
        $trx = VendTransaction::create([
            'mobile_user_id'=> 12,
            'trx_type'=> $trx_type,
            'trx_id'=> $trx_id,
        ]);
        return $trx;
    }

    private function deleteVendTrx($trx_type, $trx_id){
        $trx = VendTransaction::where('mobile_user_id', 12)->where('trx_type', $trx_type)->where('trx_id', $trx_id)->delete();
        return $trx;
    }

    private function retrieveVendTrx($trx_type){
        $trx = VendTransaction::where('mobile_user_id', 12)->where('trx_type', $trx_type)->first();
        return $trx;
    }

    private function storeNewApiData($trx_type, $trx_id, $trx_data){
        $trx = NewApiTransaction::create([
            'mobile_user_id'=> 12,
            'trx_type'=> $trx_type,
            'trx_id'=> $trx_id,
            'trx_data'=> $trx_data,
        ]);
        return $trx;
    }

    public function success(){
        return view('schedule.success');
    }

    public function error(){
        return view('schedule.error');
    }
}