<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WaterController extends Controller
{
    public function dashboard(){
        return view('water.dashbaord');
    }
}