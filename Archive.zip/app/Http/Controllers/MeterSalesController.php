<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use Illuminate\Http\Request;
use App\Models\ElectrixMeter;
use Illuminate\Support\Carbon;

class MeterSalesController extends Controller
{
    public function sales(){
        return response([
            'sales' => Sale::where('mobile_user_id', auth()->user()->mobileUser->id)
                             ->with('regmeter', 'electrixmeter')->limit(3)->latest()->get(),
        ],200);
    }

    public function sale($id){
        $sale = Sale::with('regmeter', 'electrixmeter')->find($id);

        return response([
            'sales' => [
                'id' => $sale->id,
                'initial_cost' => $sale->initial_cost,
                'created_at' => $sale->created_at->format('d.M.Y  g:i A'),
                'token_cost' => $sale->token_cost,
                'token_cost' => $sale->token_cost,
                'units' => $sale->units,
                'reg_meter_token' => $sale->reg_meter_token,
                'electrix_meter_token' => $sale->electrix_meter_token,
                'reg_meter_number' => $sale->regmeter->reg_meter_number,
                'electrix_meter_number' => $sale->electrixmeter->electrix_meter_number,
                'firstname' => $sale->regmeter->client->firstname,
                'lastname' => $sale->regmeter->client->lastname,
            ]
            ],200);
    }

    public function validateMeter($id){
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();
        
        if($meter != ''){
            return response([
                'meter' => [
                    'reg_meter_number' => $meter->regmeter->reg_meter_number,
                    'meter_owner' => $meter->regmeter->client->firstname . " " . $meter->regmeter->client->lastname,
                    'meter_status' => $meter->meter_status,
                    'user_id' => auth()->user()->mobileUser->id,
                    'reg_meter_id' => $meter->regmeter->id,
                    'electrix_meter_id' =>$meter->id,
                    'meter_type' => $meter->regmeter->meter_type,
                ]
            ],200);
        }
        else
        {
            return response([
                'meter' => [
                    'reg_meter_number' => null,
                    'meter_owner' => null,
                    'meter_status' => null,
                    'meter_type' => null,
                ]
            ],200);
        }
    }

    public function saleStore(Request $request){
        $attrs = $request->validate([
            'userId' => 'required',
            'regId' => 'required',
            'electrixId' => 'required',
            'initialCost'=> 'required',
            'tokenCost' => 'required',
            'regToken' => 'required',
            'electrixToken' => 'required',
            'units' => 'required',
        ]);
        $sale = Sale::create([
            'mobile_user_id' => $attrs['userId'],
            'reg_meter_id' => $attrs['regId'],
            'electrix_meter_id' => $attrs['electrixId'],
            'initial_cost' => $attrs['initialCost'],
            'token_cost' => $attrs['tokenCost'],
            'reg_meter_token' => $attrs['regToken'],
            'electrix_meter_token' => $attrs['electrixToken'],
            'units' => $attrs['units'],
        ]);

        return response([
            'sale' => $sale,
        ], 200);
    }

    public function monthlySales($id){
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();
        $sales = Sale::where('electrix_meter_id', $meter->id)->whereMonth('created_at', Carbon::now()->month)->sum('token_cost');
        return response([
            'sales' => [
                'sales_amount' => $sales
            ]
        ],200);
    }

    public function saleUpdate($id){
        $sale_id = Sale::where('electrix_meter_id', $id)->orderBy('id', 'DESC')->first();
        $sale = Sale::where('id', $sale_id->id)->update([
            'commussion_status' => 'Paid',
        ]);

        return response([
            'sale' => $sale_id,
        ],200);
    }

    public function saleRedirect($id){
        $sale = Sale::with('regmeter', 'electrixmeter')->where('electrix_meter_id',$id)->orderBy('id', 'DESC')->first();

        return response([
            'sale' => [
                'id' => $sale->id,
                'initial_cost' => $sale->initial_cost,
                'created_at' => $sale->created_at->format('d.M.Y  g:i A'),
                'token_cost' => $sale->token_cost,
                'units' => $sale->units,
                'reg_meter_token' => $sale->reg_meter_token,
                'electrix_meter_token' => $sale->electrix_meter_token,
                'reg_meter_number' => $sale->regmeter->reg_meter_number,
                'electrix_meter_number' => $sale->electrixmeter->electrix_meter_number,
                'firstname' => $sale->regmeter->client->firstname,
                'lastname' => $sale->regmeter->client->lastname,
            ]
            ],200);
    }

    public function fdiTansactions(){
        return view('meter.fdi-transactions');
    }

    public function generateInvoice(){
        return view('meter.generate-invoice');
    }
    
}