<?php

namespace App\Http\Controllers;

use App\Models\Admins;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware(['Admin']);
    }

    public function index(){
        return view('admin.index');
    }

    public function create(){
        if(auth()->user()->role->name == 'super_admin'){
            return view('admin.create');
        }else{
            return redirect()->to('/dashboard')->with('error', 'Unauthorized Action!');
        }
    }

    public function show($id){
        return view('admin.show',[
            'admin' => Admins::find($id),
        ]);
    }

    public function edit($id){
        if(auth()->user()->role->name == 'super_admin'){
            return view('admin.update',['id' => $id]);
        }else{
            return redirect()->to('/dashboard')->with('error', 'Unauthorized Action!');
        }
    }
}
