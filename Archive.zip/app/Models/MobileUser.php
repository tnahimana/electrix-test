<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MobileUser extends Model
{
     use HasFactory;

    protected $table = 'mobile_users';

    protected $fillable = [
        'firstname',
        'middlename',
        'lastname',
        'email',
        'phone',
        'password',
        'user_id',
    ];

    protected $hidden = [
        'password',
    ];
}
