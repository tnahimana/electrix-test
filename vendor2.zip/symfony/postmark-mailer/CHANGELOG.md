CHANGELOG
=========

4.4.0
-----

 * added `ReplyTo` option
 * [BC BREAK] Renamed and moved `Symfony\Component\Mailer\Bridge\Postmark\Http\Api\PostmarkTransport`
   to `Symfony\Component\Mailer\Bridge\Postmark\Transport\PostmarkApiTransport`, `Symfony\Component\Mailer\Bridge\Postmark\Smtp\PostmarkTransport`
   to `Symfony\Component\Mailer\Bridge\Postmark\Transport\PostmarkSmtpTransport`.

4.3.0
-----

 * Added the bridge
