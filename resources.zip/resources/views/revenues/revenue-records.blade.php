@extends('../layout/' . $layout)

@section('title')
    Revenue Records | Electrix Vending
@endsection

@section('active-sale')
    side-menu--active
@endsection

@section('navigation')
    Revenue Records
@endsection

@section('navigation-url')
    revenue-records
@endsection

@section('subcontent')
    @livewire('revenues.revenue-records')
@endsection