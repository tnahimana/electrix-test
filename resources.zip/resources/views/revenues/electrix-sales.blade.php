@extends('../layout/' . $layout)

@section('title')
    Electrix Sales | Electrix Vending
@endsection

@section('active-meters')
    side-menu--active
@endsection

@section('navigation')
    Electrix Sales
@endsection

@section('navigation-url')
    electrix-sales
@endsection

@section('subcontent')
    @livewire('revenues.electrix-sales')
@endsection
