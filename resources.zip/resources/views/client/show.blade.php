@extends('../layout/' . $layout)

@section('title')
    Client Info | Electrix Vending
@endsection
@section('active-client')
    side-menu--active
@endsection

@section('navigation')
    Client Info
@endsection

@section('navigation-url')
    {{ $client->id }}
@endsection

@section('active-client')
    side-menu--active
@endsection

@section('subcontent')
    @livewire('client.client-show', ['id' => $client->id])
@endsection