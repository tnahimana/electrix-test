@extends('../layout/' . $layout)

@section('title')
    Agent Info | Electrix Vending
@endsection
@section('active-agent')
    side-menu--active
@endsection

@section('navigation')
    Agent Info
@endsection

@section('navigation-url')
    agents/{{ $agent }}
@endsection

@section('active-agent')
    side-menu--active
@endsection

@section('subcontent')
    @livewire('agent.agent-show', ['id' => $agent])
@endsection