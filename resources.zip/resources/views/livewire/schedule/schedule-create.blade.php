<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y flex items-center mt-6 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Schedule Sale</h2>
                    </div>

                    <div class="intro-y box mt-5">

                        <div id="inline-form" class="p-5">
                            
                                <div class="flex flex-wrap -mx-3 mb-2">

                                    <div class="w-full md:w-1/3 px-3">
                                        <x-simple-select
                                            name="mobile_user"
                                            id="mobile_user"
                                            :options="$mobile_users"
                                            value-field='id'
                                            text-field='phone'
                                            placeholder="Select User"
                                            search-input-placeholder="Select User"
                                            :searchable="true"
                                            id="input-state-3"
                                            wire:model="mobile_user"
                                            class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        />
                                        @error('mobile_user')
                                            <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="w-full md:w-1/3 px-3">
                                        <x-simple-select
                                            name="electrix_meter"
                                            id="electrix_meter"
                                            :options="$electrix_meters"
                                            value-field='id'
                                            text-field='meter_number'
                                            placeholder="Select Electrix Meter"
                                            search-input-placeholder="Select Electrix Meter"
                                            :searchable="true"
                                            id="input-state-3"
                                            wire:model="electrix_meter"
                                            class="form-select mb-2 box mt-2 sm:mt-0 block w-full border border-gray-300 text-gray-700 py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        />
                                        @error('electrix_meter')
                                            <div class="text-theme-6 mt-2 text-xs mb-2">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                        <div class="md:mr-2">
                                            <input style="height: 50px" id="input-state-1" wire:model="cost" type="number" class="form-control @error('cost') border-theme-6 @elseif($cost != "") border-theme-9 @enderror" placeholder="Cost...">
                                            @error('cost')
                                                <div class="text-theme-6 text-xs mt-2">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                </div>

                                <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end">
                                        <button type="submit" style="background-color: rgb(17, 17, 134)" class="btn btn-primary pl-5 pr-5 mt-5 mr-2 mb-2"> Submit <div wire:loading.delay>ing... <i  data-color="white" class="fas fa-spinner fa-pulse w-4 h-4 ml-2"></i> </div> </button>
                                </div>

                        </div>

                    </div>

                </div>
            </form>
        </div>

    </div>
</div>