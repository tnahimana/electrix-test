@extends('../layout/' . $layout)

@section('title')
    Admin Info | Electrix Vending
@endsection
@section('active')
    side-menu--active
@endsection

@section('navigation')
    Admin Info
@endsection

@section('navigation-url')
    admins/{{ $admin->id }}
@endsection

@section('active-admin')
    side-menu--active
@endsection

@section('subcontent')
    @livewire('admin.admin-show', ['id' => $admin->id])
@endsection