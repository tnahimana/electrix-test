const set = require('regenerate')();
set.addRange(0xA800, 0xA82C);
exports.characters = set;
