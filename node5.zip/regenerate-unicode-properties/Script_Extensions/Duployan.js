const set = require('regenerate')();
set.addRange(0x1BC00, 0x1BC6A).addRange(0x1BC70, 0x1BC7C).addRange(0x1BC80, 0x1BC88).addRange(0x1BC90, 0x1BC99).addRange(0x1BC9C, 0x1BCA3);
exports.characters = set;
