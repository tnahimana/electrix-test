const set = require('regenerate')();
set.addRange(0x1C50, 0x1C7F);
exports.characters = set;
