const set = require('regenerate')();
set.addRange(0x10F00, 0x10F27);
exports.characters = set;
