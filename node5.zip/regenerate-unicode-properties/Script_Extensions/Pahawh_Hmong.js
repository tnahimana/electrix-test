const set = require('regenerate')();
set.addRange(0x16B00, 0x16B45).addRange(0x16B50, 0x16B59).addRange(0x16B5B, 0x16B61).addRange(0x16B63, 0x16B77).addRange(0x16B7D, 0x16B8F);
exports.characters = set;
