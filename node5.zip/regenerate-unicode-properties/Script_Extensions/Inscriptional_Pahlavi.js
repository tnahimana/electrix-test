const set = require('regenerate')();
set.addRange(0x10B60, 0x10B72).addRange(0x10B78, 0x10B7F);
exports.characters = set;
