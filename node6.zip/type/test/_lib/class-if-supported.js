"use strict";

try { module.exports = eval("(class {})"); }
catch (error) {}
