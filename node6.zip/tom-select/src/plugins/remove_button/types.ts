
export type RBOptions = {
	label     ?: string,
	title     ?: string,
	className ?: string,
	append    ?: boolean
};
