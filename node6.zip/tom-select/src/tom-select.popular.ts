import TomSelect from './tom-select';
import './plugins/dropdown_input/plugin.js';
import './plugins/no_backspace_delete/plugin.js';
import './plugins/remove_button/plugin.js';
import './plugins/restore_on_backspace/plugin.js';


export default TomSelect;
